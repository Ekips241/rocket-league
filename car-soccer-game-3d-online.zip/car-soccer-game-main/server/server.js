/**
 * Servidor de Car Soccer: HTTP estático + WebSocket (RFC 6455, sin dependencias) + salas por código.
 * El servidor es la autoridad de: pelota, marcador, cronómetro, pads de turbo y reinicios de saque.
 * Cada cliente simula su propio coche y envía su estado ~30 veces/s; el servidor lo reparte en snapshots a 30 Hz.
 *
 * Uso:  node server/server.js      (PORT=3000 por defecto)
 */
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const RL = require('../shared/rlcore.js');

const ROOT = path.join(__dirname, '..');
const PORT = parseInt(process.env.PORT, 10) || 3000;
const THREE_VERSION = '0.152.2';
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.md': 'text/plain; charset=utf-8' };
const PUBLIC_DIRS = ['css', 'js', 'shared', 'assets'];

// ------------------------------------------------------------------ HTTP
const server = http.createServer((req, res) => {
  let url = decodeURIComponent((req.url || '/').split('?')[0]);
  if (url === '/') url = '/index.html';
  if (url === '/health') { res.writeHead(200); return res.end('ok'); }
  // three.js: desde node_modules si existe; si no, redirige a la CDN
  if (url.startsWith('/vendor/three/')) {
    const rel = url.slice('/vendor/three/'.length);
    const f = path.join(ROOT, 'node_modules', 'three', rel);
    if (f.startsWith(path.join(ROOT, 'node_modules', 'three')) && fs.existsSync(f)) return sendFile(res, f);
    res.writeHead(302, { Location: 'https://cdn.jsdelivr.net/npm/three@' + THREE_VERSION + '/' + rel });
    return res.end();
  }
  const top = url.split('/')[1];
  if (url !== '/index.html' && !PUBLIC_DIRS.includes(top)) { res.writeHead(404); return res.end('Not found'); }
  const f = path.normalize(path.join(ROOT, url));
  if (!f.startsWith(ROOT)) { res.writeHead(403); return res.end(); }
  sendFile(res, f);
});
function sendFile(res, f) {
  fs.readFile(f, (err, data) => {
    if (err) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(data);
  });
}

// ------------------------------------------------------ WebSocket mínimo
const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
class WSConn {
  constructor(socket) {
    this.socket = socket; this.buf = Buffer.alloc(0); this.alive = true; this.lastPong = Date.now();
    this.onmessage = null; this.onclose = null; this.frag = null;
    socket.on('data', d => this._data(d));
    socket.on('close', () => this._closed()); socket.on('error', () => this._closed());
  }
  _closed() { if (this.alive) { this.alive = false; this.onclose && this.onclose(); } }
  _data(d) {
    this.buf = Buffer.concat([this.buf, d]);
    if (this.buf.length > 1 << 20) return this.close();
    for (;;) {
      const b = this.buf; if (b.length < 2) return;
      const fin = (b[0] & 0x80) !== 0, op = b[0] & 0x0f, masked = (b[1] & 0x80) !== 0; let len = b[1] & 0x7f, off = 2;
      if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (b.length < 10) return; len = Number(b.readBigUInt64BE(2)); off = 10; }
      if (len > 65536) return this.close();
      if (!masked) return this.close();            // los clientes siempre enmascaran
      if (b.length < off + 4 + len) return;
      const mask = b.slice(off, off + 4); const payload = Buffer.from(b.slice(off + 4, off + 4 + len));
      for (let i = 0; i < payload.length; i++) payload[i] ^= mask[i & 3];
      this.buf = b.slice(off + 4 + len);
      if (op === 8) return this.close();
      if (op === 9) { this._frame(10, payload); continue; }
      if (op === 10) { this.lastPong = Date.now(); continue; }
      if (op === 1 || op === 2) this.frag = { op, parts: [payload] }; else if (op === 0 && this.frag) this.frag.parts.push(payload);
      if (fin && this.frag) { const msg = Buffer.concat(this.frag.parts); this.frag = null; if (this.onmessage) this.onmessage(msg.toString('utf8')); }
    }
  }
  _frame(op, payload) {
    if (!this.alive) return;
    const len = payload.length; let h;
    if (len < 126) h = Buffer.from([0x80 | op, len]);
    else if (len < 65536) { h = Buffer.alloc(4); h[0] = 0x80 | op; h[1] = 126; h.writeUInt16BE(len, 2); }
    else { h = Buffer.alloc(10); h[0] = 0x80 | op; h[1] = 127; h.writeBigUInt64BE(BigInt(len), 2); }
    try { this.socket.write(Buffer.concat([h, payload])); } catch (e) { /* socket cerrado */ }
  }
  send(obj) { this._frame(1, Buffer.from(typeof obj === 'string' ? obj : JSON.stringify(obj))); }
  ping() { this._frame(9, Buffer.alloc(0)); }
  close() { if (!this.alive) return; try { this._frame(8, Buffer.alloc(0)); this.socket.end(); } catch (e) {} this._closed(); }
}
server.on('upgrade', (req, socket) => {
  if ((req.url || '').split('?')[0] !== '/ws' || !req.headers['sec-websocket-key']) { socket.destroy(); return; }
  const accept = crypto.createHash('sha1').update(req.headers['sec-websocket-key'] + GUID).digest('base64');
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
  socket.setNoDelay(true);
  onConnection(new WSConn(socket));
});

// ------------------------------------------------------------------ salas
const rooms = new Map();
const ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';     // sin 0/O/1/I/L
let nextId = 1;
function genCode() {
  for (let n = 0; n < 1000; n++) {
    let c = ''; const r = crypto.randomBytes(6);
    for (let i = 0; i < 6; i++) c += ALPHABET[r[i] % ALPHABET.length];
    if (!rooms.has(c)) return c;
  }
  throw new Error('sin códigos libres');
}
const cleanName = n => String(n || 'Jugador').replace(/[^\p{L}\p{N} _\-.]/gu, '').trim().slice(0, 16) || 'Jugador';
const HEX = /^#[0-9a-fA-F]{6}$/;
function cleanLook(l) {
  l = l || {}; const col = (v, d) => HEX.test(v) ? v : d;
  return { c1: col(l.c1, '#00d4ff'), c2: col(l.c2, '#101828'), wheel: col(l.wheel, '#222222'),
           finish: ['gloss', 'matte', 'metal', 'pearl'].includes(l.finish) ? l.finish : 'gloss', type: typeof l.type === 'string' ? l.type.slice(0, 20) : 'fennec' };
}
const finite3 = a => Array.isArray(a) && a.length === 3 && a.every(Number.isFinite);

class Room {
  constructor(code) {
    this.code = code; this.match = new RL.Match(); this.clients = new Map(); this.acc = 0; this.snapAcc = 0; this.last = Date.now(); this.emptySince = null;
  }
  playersList() {
    return this.match.order.map(id => { const c = this.match.cars[id]; return { id, name: c.name, team: c.team, look: c.look, goals: c.goals }; });
  }
  broadcast(obj, except) { const s = JSON.stringify(obj); this.clients.forEach((ws, id) => { if (id !== except) ws.send(s); }); }
  tick(now) {
    let dt = Math.min((now - this.last) / 1000, 0.1); this.last = now;
    this.acc += dt;
    while (this.acc >= RL.C.TICK) { this.match.step(RL.C.TICK); this.acc -= RL.C.TICK; this.flushEvents(); }
    this.snapAcc += dt;
    if (this.snapAcc >= 1 / 30) {
      this.snapAcc = 0;
      if (this.clients.size) { const s = this.match.snapshot(); s.t = 'snap'; s.ts = now; this.broadcast(s); }
    }
  }
  flushEvents() {
    this.match.drainEvents().forEach(e => {
      if (e.type === 'pickup') { const ws = this.clients.get(e.id); if (ws) ws.send({ t: 'ev', e }); return; }
      if (e.type === 'goal' || e.type === 'end') e.players = this.playersList();
      this.broadcast({ t: 'ev', e });
    });
  }
}

function onConnection(ws) {
  const id = 'p' + (nextId++); let room = null, msgCount = 0, windowStart = Date.now();
  ws.send({ t: 'hello', id });
  const fail = m => ws.send({ t: 'error', msg: m });
  function enter(r, name, look) {
    const car = r.match.addPlayer(id, { name, look });
    if (!car) return fail('La sala está llena (máx. 8 jugadores).');
    room = r; r.clients.set(id, ws); r.emptySince = null;
    const sp = RL.spawnFor(car.team, car.spawn);
    ws.send({ t: 'joined', room: r.code, you: id, team: car.team, spawn: sp, players: r.playersList(), max: RL.C.MAX_PLAYERS });
    r.broadcast({ t: 'players', players: r.playersList(), joined: id, name }, id);
  }
  ws.onmessage = raw => {
    const now = Date.now(); if (now - windowStart > 1000) { windowStart = now; msgCount = 0; }
    if (++msgCount > 200) return;                     // anti-flood
    let m; try { m = JSON.parse(raw); } catch (e) { return; }
    if (!m || typeof m.t !== 'string') return;
    switch (m.t) {
      case 'create': { if (room) return; const r = new Room(genCode()); rooms.set(r.code, r); enter(r, cleanName(m.name), cleanLook(m.look)); break; }
      case 'join': {
        if (room) return; const code = String(m.code || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
        const r = rooms.get(code); if (!r) return fail('No existe ninguna sala con el código ' + code + '.');
        enter(r, cleanName(m.name), cleanLook(m.look)); break;
      }
      case 's': {
        if (!room) return; const q = m.q;
        if (!finite3(m.p) || !finite3(m.v) || !finite3(m.w) || !Array.isArray(q) || q.length !== 4 || !q.every(Number.isFinite)) return;
        if (Math.abs(m.p[0]) > 7000 || Math.abs(m.p[1]) > 3000 || Math.abs(m.p[2]) > 7000) return;
        room.match.setCar(id, { p: m.p, v: m.v, q: q, w: m.w, b: Math.max(0, Math.min(100, +m.b || 0)), st: +m.st || 0, f: m.f | 0 });
        break;
      }
      case 'look': { if (!room) return; const c = room.match.cars[id]; if (c) { c.look = cleanLook(m.look); if (m.name) c.name = cleanName(m.name); room.broadcast({ t: 'players', players: room.playersList() }); } break; }
      case 'ping': ws.send({ t: 'pong', ts: m.ts }); break;
      case 'leave': ws.close(); break;
    }
  };
  ws.onclose = () => {
    if (!room) return; const r = room, c = r.match.cars[id], name = c ? c.name : 'Jugador';
    r.clients.delete(id); r.match.removePlayer(id);
    r.broadcast({ t: 'left', id, name, players: r.playersList() });
    if (!r.clients.size) r.emptySince = Date.now();
  };
}

setInterval(() => {
  const now = Date.now();
  rooms.forEach((r, code) => {
    if (!r.clients.size) { if (now - r.emptySince > 30000) rooms.delete(code); return; }
    r.tick(now);
  });
}, 8);
setInterval(() => {                                    // latido: cierra conexiones muertas
  const now = Date.now();
  rooms.forEach(r => r.clients.forEach(ws => { if (now - ws.lastPong > 45000) ws.close(); else ws.ping(); }));
}, 15000);

if (require.main === module) {
  server.listen(PORT, '0.0.0.0', () => console.log('Car Soccer en http://localhost:' + PORT + '  (WebSocket: /ws)'));
  process.on('SIGTERM', () => { server.close(); process.exit(0); });   // reinicios de la plataforma
}
module.exports = { server, rooms };
