# 🚗 3D Car Soccer — fútbol con coches inspirado en Rocket League

Juego 3D para el navegador (Chrome / Edge) con físicas propias, estadio completo, bots y **multijugador online por código de sala** (hasta 8 jugadores).

## ▶️ Cómo jugar

```bash
npm install      # descarga three.js (si no lo haces, el servidor lo redirige a la CDN jsDelivr)
npm start        # http://localhost:3000
```

* **JUGAR**: partida local contra bots (nº de bots en Ajustes).
* **CREAR PARTIDA**: crea una sala, muestra un código de 6 caracteres y un botón para copiarlo.
* **UNIRSE A PARTIDA**: introduce el código. Todos aparecen en el mismo campo.
* Para jugar con amigos fuera de tu red, despliega el servidor (Render, Railway, Fly…; usa `PORT`) o expón el puerto 3000 con un túnel. Sirve el juego y el WebSocket (`/ws`) desde el mismo origen.

## 🎮 Controles

| Tecla | Acción |
|---|---|
| W/↑ · S/↓ | acelerar · marcha atrás/freno (en el aire: morro abajo/arriba) |
| A/D o ←/→ | girar (en el aire: guiñada) |
| ESPACIO | salto; pulsar otra vez en el aire = doble salto, o **voltereta** si pulsas W/S/A/D |
| SHIFT / E / clic | turbo |
| Q / CTRL | derrape (freno de mano) |
| Z / X | alabeo en el aire |
| C | cámara «seguir pelota» ↔ «detrás del coche» |
| TAB | lista de jugadores · ESC pausa |

## 🧱 Estructura

```
shared/rlcore.js   núcleo compartido navegador+servidor: arena (colisión), pelota, coche↔pelota, pads, Match
server/server.js   HTTP estático + WebSocket (RFC 6455 propio, sin dependencias) + salas
js/cars.js         física del coche (4 ruedas con suspensión, derrape, salto, voltereta, turbo, paredes)
js/carmodel.js     modelo 3D original del coche tipo Fennec (personalizable)
js/ball.js         pelota (textura hexagonal/pentagonal), estela, partículas y ondas de golpe
js/stadium.js      estadio: césped, paredes curvas, porterías, pads, marcadores, gradas, focos
js/camera.js · input.js · audio.js · ui.js · network.js · game.js · main.js
tests/             car.test.js (física) · net.test.js (servidor) · smoke.test.js · online-smoke.test.js
legacy-2d-original/ copia intacta del proyecto original
```

## 🌐 Modelo de red

El servidor es la autoridad de **pelota, marcador, cronómetro, pads de turbo y saques**. Cada cliente simula su propio coche y envía su estado ~30 veces/s; el servidor reparte *snapshots* a 30 Hz. Los clientes interpolan los coches remotos (100 ms) y **predicen la pelota con el mismo código de físicas** que el servidor, corrigiéndola con cada snapshot.

## ✅ Pruebas (`npm test`)

* Física: reposo estable de la suspensión, aceleración, giro, salto/voltereta, subida por pared, rebotes y gol.
* Servidor: dos clientes WebSocket reales, mismo código, equipos equilibrados, snapshots, desconexión.
* Cliente completo (con DOM/THREE simulados) en solo y en online con dos clientes contra el servidor.

## ⚠️ Limitaciones conocidas

* Las dimensiones y constantes (campo 8192×10240×2044, porterías 1786×642, gravedad 650, turbo 991, etc.) **aproximan** las de Rocket League; no son idénticas. Posiciones de pads aproximadas.
* Colisiones coche↔coche: cada cliente resuelve su parte (aproximación con esferas); no hay demoliciones.
* El modelo del coche es original (inspirado en las proporciones del Fennec), no un recurso del juego.

## 🚀 Subirlo a una web

El juego necesita un **servidor Node con WebSocket siempre activo**, así que no vale el hosting estático (GitHub Pages, Netlify, Vercel estático). Sirve cualquier plataforma que ejecute Node: Render, Railway, Fly.io o un VPS.

**Render (la vía más rápida):**
1. Sube la carpeta a un repositorio de GitHub (el `.gitignore` ya excluye `node_modules`).
2. En render.com: *New +* → *Web Service* → elige el repositorio.
3. Build command `npm install` · Start command `npm start` (o *New +* → *Blueprint* y usa `render.yaml`).
4. Render te da una URL `https://tu-juego.onrender.com`: ábrela y juega; tus amigos usan la misma URL con el código de sala.

HTTPS lo pone la plataforma y el cliente usa `wss://` automáticamente. Con `Dockerfile` también puedes desplegar en Fly.io/Railway/VPS.
