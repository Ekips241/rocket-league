/**
 * rlcore.js — Núcleo compartido (navegador + servidor Node).
 * Contiene: dimensiones del estadio, geometría de colisión de la arena,
 * física de la pelota, colisión coche-pelota, pads de turbo y la máquina
 * de estados de la partida (Match).
 *
 * Unidades: "unreal units" (uu) como Rocket League. Ejes (Three.js, Y arriba):
 *   X = anchura del campo, Y = altura, Z = longitud (porterías en Z = ±5120).
 * Equipo 0 (AZUL) defiende Z negativo y ataca Z positivo. Equipo 1 (NARANJA) al revés.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.RL = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  // ---------------------------------------------------------------- constantes
  const C = {
    HALF_W: 4096, HALF_L: 5120, HEIGHT: 2044,
    CORNER_R: 1152,           // radio de las esquinas curvas (vista en planta)
    FILLET_R: 520,            // radio de la rampa suelo/pared y pared/techo
    GOAL_HALF_W: 893, GOAL_H: 642, GOAL_DEPTH: 880,
    GRAVITY: 650,
    BALL_R: 91.25, BALL_MASS: 30, BALL_MAX_SPEED: 6000, BALL_MAX_ANG: 6, BALL_E: 0.6, BALL_DRAG: 0.03,
    CAR_MASS: 180, CAR_MAX_SPEED: 2300,
    // Hitbox aproximada de un coche tipo Fennec (semi-extensiones, local: X=derecha, Y=arriba, Z=atrás)
    HB: { x: 42.1, y: 18.1, z: 59.0 }, HB_OFF_UP: 12.1, HB_OFF_FWD: 9.0,
    MAX_PLAYERS: 8, MATCH_SECONDS: 300, COUNTDOWN: 3, GOAL_DELAY: 4, END_DELAY: 9,
    TICK: 1 / 120
  };

  // ------------------------------------------------------------------ arena
  // Devuelve en `o` la profundidad (d>0 = dentro, distancia a la superficie más cercana)
  // y la normal que apunta hacia el interior.
  function shellDepth(x, y, z, o) {
    const ax = Math.abs(x), az = Math.abs(z), sx = x < 0 ? -1 : 1, sz = z < 0 ? -1 : 1;
    const qx = ax - (C.HALF_W - C.CORNER_R), qz = az - (C.HALF_L - C.CORNER_R);
    let w, hx, hz;
    if (qx > 0 && qz > 0) {                       // esquina curva
      const len = Math.sqrt(qx * qx + qz * qz) || 1e-6;
      w = C.CORNER_R - len; hx = -sx * qx / len; hz = -sz * qz / len;
    } else if (qx > qz) { w = C.HALF_W - ax; hx = -sx; hz = 0; }
    else { w = C.HALF_L - az; hx = 0; hz = -sz; }
    const lower = y < C.HEIGHT / 2, yc = lower ? y : C.HEIGHT - y, ys = lower ? 1 : -1, R = C.FILLET_R;
    if (w < R && yc < R) {                        // rampa curva (suelo→pared / pared→techo)
      const dx = R - w, dy = R - yc, len = Math.sqrt(dx * dx + dy * dy) || 1e-6;
      o.d = R - len; o.nx = hx * dx / len; o.nz = hz * dx / len; o.ny = ys * dy / len;
    } else if (w < yc) { o.d = w; o.nx = hx; o.ny = 0; o.nz = hz; }
    else { o.d = yc; o.nx = 0; o.ny = ys; o.nz = 0; }
  }
  function goalDepth(x, y, z, o) {
    const ax = Math.abs(x), az = Math.abs(z), sx = x < 0 ? -1 : 1, sz = z < 0 ? -1 : 1;
    let d = C.GOAL_HALF_W - ax, nx = -sx, ny = 0, nz = 0;
    if (y < d) { d = y; nx = 0; ny = 1; nz = 0; }
    const d3 = C.GOAL_H - y; if (d3 < d) { d = d3; nx = 0; ny = -1; nz = 0; }
    const d4 = C.HALF_L + C.GOAL_DEPTH - az; if (d4 < d) { d = d4; nx = 0; ny = 0; nz = -sz; }
    o.d = d; o.nx = nx; o.ny = ny; o.nz = nz;
  }
  const _g = { d: 0, nx: 0, ny: 0, nz: 0 };
  /** Contacto con la arena = unión del recinto redondeado y las dos cajas de las porterías. */
  function arenaContact(x, y, z, o) {
    shellDepth(x, y, z, o);
    goalDepth(x, y, z, _g);
    if (_g.d > o.d) { o.d = _g.d; o.nx = _g.nx; o.ny = _g.ny; o.nz = _g.nz; }
    return o;
  }

  // ----------------------------------------------------------------- vectores
  /** Calcula los ejes del coche (derecha, arriba, atrás) a partir de un cuaternión [x,y,z,w]. */
  function quatAxes(q, o) {
    const x = q[0], y = q[1], z = q[2], w = q[3];
    o.rx = 1 - 2 * (y * y + z * z); o.ry = 2 * (x * y + z * w); o.rz = 2 * (x * z - y * w);
    o.ux = 2 * (x * y - z * w); o.uy = 1 - 2 * (x * x + z * z); o.uz = 2 * (y * z + x * w);
    o.bx = 2 * (x * z + y * w); o.by = 2 * (y * z - x * w); o.bz = 1 - 2 * (x * x + y * y);
    return o;
  }
  function quatFromYaw(yaw) { return [0, Math.sin(yaw / 2), 0, Math.cos(yaw / 2)]; }

  // ------------------------------------------------------------------ pelota
  function newBall() {
    return { px: 0, py: 200, pz: 0, vx: 0, vy: 0, vz: 0, wx: 0, wy: 0, wz: 0,
             hit: 0, wallHit: 0, tprev: {}, tnow: {} };
  }
  const _c = { d: 0, nx: 0, ny: 0, nz: 0 };

  function stepBall(b, dt) {
    b.vy -= C.GRAVITY * dt;
    const k = 1 - C.BALL_DRAG * dt;
    b.vx *= k; b.vy *= k; b.vz *= k;
    const sp = Math.sqrt(b.vx * b.vx + b.vy * b.vy + b.vz * b.vz);
    if (sp > C.BALL_MAX_SPEED) { const s = C.BALL_MAX_SPEED / sp; b.vx *= s; b.vy *= s; b.vz *= s; }
    b.px += b.vx * dt; b.py += b.vy * dt; b.pz += b.vz * dt;
    for (let i = 0; i < 3; i++) {
      arenaContact(b.px, b.py, b.pz, _c);
      const pen = C.BALL_R - _c.d;
      if (pen <= 0) break;
      b.px += _c.nx * pen; b.py += _c.ny * pen; b.pz += _c.nz * pen;
      const vn = b.vx * _c.nx + b.vy * _c.ny + b.vz * _c.nz;
      if (vn < 0) {
        const e = -vn < 40 ? 0 : C.BALL_E;
        const j = -(1 + e) * vn;
        b.vx += _c.nx * j; b.vy += _c.ny * j; b.vz += _c.nz * j;
        if (-vn > b.wallHit) b.wallHit = -vn;
      }
      // rodadura: acopla la rotación con la velocidad tangencial
      const vt = { x: b.vx - _c.nx * (b.vx * _c.nx + b.vy * _c.ny + b.vz * _c.nz),
                   y: b.vy - _c.ny * (b.vx * _c.nx + b.vy * _c.ny + b.vz * _c.nz),
                   z: b.vz - _c.nz * (b.vx * _c.nx + b.vy * _c.ny + b.vz * _c.nz) };
      const tx = (_c.ny * vt.z - _c.nz * vt.y) / C.BALL_R, ty = (_c.nz * vt.x - _c.nx * vt.z) / C.BALL_R,
            tz = (_c.nx * vt.y - _c.ny * vt.x) / C.BALL_R;
      b.wx += (tx - b.wx) * 0.08; b.wy += (ty - b.wy) * 0.08; b.wz += (tz - b.wz) * 0.08;
    }
    const wl = Math.sqrt(b.wx * b.wx + b.wy * b.wy + b.wz * b.wz);
    if (wl > C.BALL_MAX_ANG) { const s = C.BALL_MAX_ANG / wl; b.wx *= s; b.wy *= s; b.wz *= s; }
  }

  function extraScale(s) {                       // escala de impulso extra (curva tipo RL)
    if (s <= 500) return 0.65;
    if (s <= 2300) return 0.65 + (s - 500) / 1800 * (0.55 - 0.65);
    if (s <= 4600) return 0.55 + (s - 2300) / 2300 * (0.30 - 0.55);
    return 0.30;
  }
  const _ax = {};
  /** Colisión esfera (pelota) vs hitbox orientada del coche. Devuelve la fuerza del golpe (Δv de la pelota). */
  function carBallCollide(b, car, first, ex) {
    // ex = extrapolación (posición del coche ya adelantada)
    const cx = ex.x + car.ux * C.HB_OFF_UP - car.bx * C.HB_OFF_FWD,
          cy = ex.y + car.uy * C.HB_OFF_UP - car.by * C.HB_OFF_FWD,
          cz = ex.z + car.uz * C.HB_OFF_UP - car.bz * C.HB_OFF_FWD;
    const dx = b.px - cx, dy = b.py - cy, dz = b.pz - cz;
    const lx = dx * car.rx + dy * car.ry + dz * car.rz,
          ly = dx * car.ux + dy * car.uy + dz * car.uz,
          lz = dx * car.bx + dy * car.by + dz * car.bz;
    const qx = Math.max(-C.HB.x, Math.min(C.HB.x, lx)), qy = Math.max(-C.HB.y, Math.min(C.HB.y, ly)),
          qz = Math.max(-C.HB.z, Math.min(C.HB.z, lz));
    const ex_ = lx - qx, ey_ = ly - qy, ez_ = lz - qz;
    const dist2 = ex_ * ex_ + ey_ * ey_ + ez_ * ez_;
    if (dist2 >= C.BALL_R * C.BALL_R) return 0;
    let dist = Math.sqrt(dist2), nlx, nly, nlz;
    if (dist < 1e-4) { nlx = 0; nly = 1; nlz = 0; dist = 0; } else { nlx = ex_ / dist; nly = ey_ / dist; nlz = ez_ / dist; }
    const nx = car.rx * nlx + car.ux * nly + car.bx * nlz,
          ny = car.ry * nlx + car.uy * nly + car.by * nlz,
          nz = car.rz * nlx + car.uz * nly + car.bz * nlz;
    const pen = C.BALL_R - dist;
    b.px += nx * pen; b.py += ny * pen; b.pz += nz * pen;
    const rvx = b.vx - car.vx, rvy = b.vy - car.vy, rvz = b.vz - car.vz;
    const vn = rvx * nx + rvy * ny + rvz * nz;
    const speed = Math.sqrt(rvx * rvx + rvy * rvy + rvz * rvz);
    const v0 = Math.sqrt(b.vx * b.vx + b.vy * b.vy + b.vz * b.vz);
    if (vn < 0) {
      const j = -vn / (1 / C.BALL_MASS + 1 / C.CAR_MASS) / C.BALL_MASS;
      b.vx += nx * j; b.vy += ny * j; b.vz += nz * j;
    }
    if (first) {                                  // impulso extra de "golpeo" (sólo en el primer contacto)
      let ex2 = b.px - cx, ey2 = (b.py - cy) * 0.35, ez2 = b.pz - cz;
      const l = Math.sqrt(ex2 * ex2 + ey2 * ey2 + ez2 * ez2) || 1;
      const mag = speed * extraScale(speed);
      b.vx += ex2 / l * mag; b.vy += ey2 / l * mag; b.vz += ez2 / l * mag;
    }
    // rotación por fricción
    const tvx = rvx - nx * vn, tvy = rvy - ny * vn, tvz = rvz - nz * vn;
    b.wx += (-(ny * tvz - nz * tvy) / C.BALL_R * 0.5 - b.wx) * 0.15;
    b.wy += (-(nz * tvx - nx * tvz) / C.BALL_R * 0.5 - b.wy) * 0.15;
    b.wz += (-(nx * tvy - ny * tvx) / C.BALL_R * 0.5 - b.wz) * 0.15;
    const v1 = Math.sqrt(b.vx * b.vx + b.vy * b.vy + b.vz * b.vz);
    const sp = Math.sqrt(b.vx * b.vx + b.vy * b.vy + b.vz * b.vz);
    if (sp > C.BALL_MAX_SPEED) { const s = C.BALL_MAX_SPEED / sp; b.vx *= s; b.vy *= s; b.vz *= s; }
    const strength = Math.abs(v1 - v0) + (first ? 0 : 0);
    if (first && strength > b.hit) b.hit = strength;
    return strength;
  }

  // --------------------------------------------------------------- pads turbo
  const BIG = [[-3584, 0], [3584, 0], [-3072, -4096], [3072, -4096], [-3072, 4096], [3072, 4096]];
  const SMALL = [[0, -4240], [0, 4240], [-1792, -4184], [1792, -4184], [-1792, 4184], [1792, 4184],
    [-940, -3308], [940, -3308], [-940, 3308], [940, 3308], [-3584, -2484], [3584, -2484], [-3584, 2484], [3584, 2484],
    [0, -2816], [0, 2816], [-1788, -2300], [1788, -2300], [-1788, 2300], [1788, 2300], [-2048, -1036], [2048, -1036],
    [-2048, 1036], [2048, 1036], [-1024, 0], [1024, 0], [0, -1024], [0, 1024]];
  function makePads() {
    const p = [];
    BIG.forEach(a => p.push({ x: a[0], z: a[1], big: true, t: 0 }));
    SMALL.forEach(a => p.push({ x: a[0], z: a[1], big: false, t: 0 }));
    return p;
  }

  // ------------------------------------------------------------------- partida
  const SPAWNS = [[-2048, 2560], [2048, 2560], [-256, 3840], [256, 3840]];   // |z| y x por orden de llegada
  function spawnFor(team, idx) {
    const s = SPAWNS[idx % SPAWNS.length];
    const sign = team === 0 ? -1 : 1;                       // azul empieza en Z-, naranja en Z+
    const mirror = team === 0 ? 1 : -1;
    return { x: s[0] * mirror, z: sign * s[1], yaw: team === 0 ? Math.PI : 0 };
    // yaw=0 → el coche mira hacia -Z; yaw=π → mira hacia +Z
  }

  class Match {
    constructor(opts) {
      opts = opts || {};
      this.duration = opts.duration || C.MATCH_SECONDS;
      this.ball = newBall(); this.cars = {}; this.order = [];
      this.score = [0, 0]; this.time = this.duration; this.overtime = false;
      this.phase = 'countdown'; this.phaseT = C.COUNTDOWN; this.clock = 0;
      this.pads = makePads(); this.events = []; this.winner = -1; this.lastGoal = null;
      this.resetKickoff();
    }
    /** Añade jugador; reparte equipos de forma equilibrada. */
    addPlayer(id, info) {
      if (this.order.length >= C.MAX_PLAYERS) return null;
      const cnt = [0, 0]; this.order.forEach(i => cnt[this.cars[i].team]++);
      const team = info.team != null ? info.team : (cnt[0] <= cnt[1] ? 0 : 1);
      const idx = cnt[team];
      const sp = spawnFor(team, idx);
      const car = Object.assign({ id: id, name: 'Jugador', team: team, boost: 33, st: 0, fl: 0, stamp: this.clock, q: quatFromYaw(sp.yaw),
        px: sp.x, py: 18, pz: sp.z, vx: 0, vy: 0, vz: 0, wx: 0, wy: 0, wz: 0, spawn: idx, goals: 0 }, info || {}, { team: team, id: id });
      quatAxes(car.q, car);
      this.cars[id] = car; this.order.push(id);
      return car;
    }
    removePlayer(id) { delete this.cars[id]; this.order = this.order.filter(i => i !== id); }
    resetKickoff() {
      const b = this.ball; b.px = 0; b.py = C.BALL_R + 1; b.pz = 0; b.vx = b.vy = b.vz = 0; b.wx = b.wy = b.wz = 0; b.tprev = {}; b.tnow = {};
      const cnt = [0, 0], spawns = {};
      this.order.forEach(id => {
        const c = this.cars[id]; const idx = cnt[c.team]++; c.spawn = idx;
        const sp = spawnFor(c.team, idx);
        c.px = sp.x; c.py = 18; c.pz = sp.z; c.vx = c.vy = c.vz = 0; c.wx = c.wy = c.wz = 0;
        c.q = quatFromYaw(sp.yaw); quatAxes(c.q, c); c.boost = 33; c.stamp = this.clock;
        spawns[id] = { x: sp.x, z: sp.z, yaw: sp.yaw };
      });
      this.pads.forEach(p => p.t = 0);
      this.phase = 'countdown'; this.phaseT = C.COUNTDOWN;
      this.events.push({ type: 'kickoff', spawns: spawns });
    }
    /** Actualiza el estado de un coche con lo que reporta su cliente. */
    setCar(id, s) {
      const c = this.cars[id]; if (!c) return;
      c.px = s.p[0]; c.py = s.p[1]; c.pz = s.p[2]; c.vx = s.v[0]; c.vy = s.v[1]; c.vz = s.v[2];
      c.q = s.q; c.wx = s.w[0]; c.wy = s.w[1]; c.wz = s.w[2]; c.boost = s.b; c.st = s.st || 0; c.fl = s.f | 0;
      c.stamp = this.clock; quatAxes(c.q, c);
    }
    step(dt) {
      this.clock += dt;
      for (let i = 0; i < this.pads.length; i++) if (this.pads[i].t > 0) this.pads[i].t -= dt;
      const b = this.ball;
      if (this.phase === 'countdown') {
        this.phaseT -= dt;
        if (this.phaseT <= 0) { this.phase = 'playing'; this.events.push({ type: 'go' }); }
        return;
      }
      if (this.phase === 'ended') {
        this.phaseT -= dt;
        if (this.phaseT <= 0) { this.score = [0, 0]; this.time = this.duration; this.overtime = false; this.winner = -1;
          this.order.forEach(i => this.cars[i].goals = 0); this.events.push({ type: 'newmatch' }); this.resetKickoff(); }
        return;
      }
      // pelota + coches
      stepBall(b, dt);
      b.tnow = {};
      for (let i = 0; i < this.order.length; i++) {
        const c = this.cars[this.order[i]];
        const age = Math.min(this.clock - c.stamp, 0.12);
        const hit = carBallCollide(b, c, !b.tprev[c.id], { x: c.px + c.vx * age, y: c.py + c.vy * age, z: c.pz + c.vz * age });
        if (hit > 0) { b.tnow[c.id] = true; if (b.hit > 0) c.lastTouch = this.clock; }
      }
      b.tprev = b.tnow;
      if (this.phase === 'goal') {
        this.phaseT -= dt;
        if (this.phaseT <= 0) { if (this.time <= 0 && !this.overtime) this._end(); else this.resetKickoff(); }
        return;
      }
      // playing
      this._pickups();
      if (!this.overtime) {
        this.time -= dt;
        if (this.time <= 0) { this.time = 0; if (this.score[0] === this.score[1]) { this.overtime = true; this.events.push({ type: 'overtime' }); } else this._end(); }
      }
      if (this.phase === 'playing' && Math.abs(b.pz) > C.HALF_L + C.BALL_R && Math.abs(b.px) < C.GOAL_HALF_W && b.py < C.GOAL_H) {
        const team = b.pz > 0 ? 0 : 1;
        this.score[team]++;
        let scorer = null, bt = -1;
        this.order.forEach(i => { const c = this.cars[i]; if (c.team === team && c.lastTouch > bt) { bt = c.lastTouch; scorer = c.id; } });
        if (scorer && this.clock - bt < 10) this.cars[scorer].goals++; else scorer = null;
        this.lastGoal = { team: team, scorer: scorer };
        this.phase = 'goal'; this.phaseT = C.GOAL_DELAY;
        this.events.push({ type: 'goal', team: team, scorer: scorer, score: this.score.slice() });
      }
    }
    _end() {
      this.phase = 'ended'; this.phaseT = C.END_DELAY;
      this.winner = this.score[0] > this.score[1] ? 0 : this.score[1] > this.score[0] ? 1 : -1;
      this.events.push({ type: 'end', winner: this.winner, score: this.score.slice() });
    }
    _pickups() {
      for (let i = 0; i < this.order.length; i++) {
        const c = this.cars[this.order[i]];
        if (c.boost >= 99.5 || c.py > 150) continue;
        for (let k = 0; k < this.pads.length; k++) {
          const p = this.pads[k]; if (p.t > 0) continue;
          const dx = c.px - p.x, dz = c.pz - p.z, r = p.big ? 208 : 144;
          if (dx * dx + dz * dz < r * r) {
            p.t = p.big ? 10 : 4;
            const add = p.big ? 100 : 12; c.boost = Math.min(100, c.boost + add);
            this.events.push({ type: 'pickup', id: c.id, pad: k, boost: c.boost });
          }
        }
      }
    }
    drainEvents() { const e = this.events; this.events = []; return e; }
    /** Estado compacto para enviar por red. */
    snapshot() {
      const r = (n) => Math.round(n * 10) / 10, b = this.ball, cars = {};
      this.order.forEach(id => { const c = this.cars[id];
        cars[id] = [r(c.px), r(c.py), r(c.pz), r(c.vx), r(c.vy), r(c.vz), c.q.map(n => Math.round(n * 1e4) / 1e4), c.boost | 0, c.fl, Math.round(c.st * 100) / 100]; });
      return { ball: [r(b.px), r(b.py), r(b.pz), r(b.vx), r(b.vy), r(b.vz), Math.round(b.wx * 100) / 100, Math.round(b.wy * 100) / 100, Math.round(b.wz * 100) / 100],
        cars: cars, score: this.score, time: Math.round(this.time * 10) / 10, ot: this.overtime, ph: this.phase, pt: Math.round(this.phaseT * 10) / 10,
        pads: this.pads.map(p => p.t > 0 ? 1 : 0).join('') };
    }
  }

  return { C: C, Match: Match, arenaContact: arenaContact, newBall: newBall, stepBall: stepBall, carBallCollide: carBallCollide,
           quatAxes: quatAxes, quatFromYaw: quatFromYaw, spawnFor: spawnFor, makePads: makePads, BIG: BIG, SMALL: SMALL };
});
