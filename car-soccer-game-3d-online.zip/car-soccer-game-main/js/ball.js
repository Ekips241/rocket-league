// Ball Configuration (original conservada; se añaden los valores en unidades de juego)
const BALL_CONFIG = {
    radius: 0.7,
    mass: 1,
    friction: 0.98,
    bounceDamping: 0.6,
    maxVelocity: 60,
    // Valores reales del juego (uu, ver shared/rlcore.js)
    gameRadius: 91.25,
    gameMaxSpeed: 6000
};

/**
 * Textura de balón de fútbol: 12 pentágonos oscuros + 20 hexágonos claros (icosaedro truncado),
 * generada por píxel como diagrama de Voronoi esférico de los 32 centros de cara.
 */
function createBallTexture(W, H) {
    W = W || 1024; H = H || 512;
    const phi = (1 + Math.sqrt(5)) / 2, pent = [], hex = [];
    const norm = v => { const l = Math.hypot(v[0], v[1], v[2]); return [v[0] / l, v[1] / l, v[2] / l]; };
    [[0, 1, phi], [0, -1, phi], [0, 1, -phi], [0, -1, -phi]].forEach(v => {          // 12 vértices del icosaedro
        pent.push(norm(v)); pent.push(norm([v[1], v[2], v[0]])); pent.push(norm([v[2], v[0], v[1]]));
    });
    for (let a = -1; a <= 1; a += 2) for (let b = -1; b <= 1; b += 2) for (let c = -1; c <= 1; c += 2) hex.push(norm([a, b, c]));   // 8 de 20 caras
    [[0, 1 / phi, phi], [0, 1 / phi, -phi], [0, -1 / phi, phi], [0, -1 / phi, -phi]].forEach(v => {                  // 12 restantes
        hex.push(norm(v)); hex.push(norm([v[1], v[2], v[0]])); hex.push(norm([v[2], v[0], v[1]]));
    });
    const centers = pent.map(v => ({v, p: true})).concat(hex.map(v => ({v, p: false})));
    const cv = document.createElement('canvas'); cv.width = W; cv.height = H;
    const ctx = cv.getContext('2d'), img = ctx.createImageData(W, H), d = img.data;
    for (let y = 0; y < H; y++) {
        const lat = Math.PI / 2 - (y + 0.5) / H * Math.PI, cl = Math.cos(lat), sl = Math.sin(lat);
        for (let x = 0; x < W; x++) {
            const lon = (x + 0.5) / W * Math.PI * 2, dx = cl * Math.cos(lon), dy = sl, dz = cl * Math.sin(lon);
            let b1 = -2, b2 = -2, bp = false;
            for (let i = 0; i < centers.length; i++) {
                const c = centers[i].v, dot = dx * c[0] + dy * c[1] + dz * c[2];
                if (dot > b1) { b2 = b1; b1 = dot; bp = centers[i].p; } else if (dot > b2) b2 = dot;
            }
            const seam = (b1 - b2) < 0.018, o = (y * W + x) * 4;
            const col = seam ? [34, 44, 62] : bp ? [20, 28, 44] : [238, 242, 250];
            d[o] = col[0]; d[o + 1] = col[1]; d[o + 2] = col[2]; d[o + 3] = 255;
        }
    }
    ctx.putImageData(img, 0, 0);
    const t = new THREE.CanvasTexture(cv); t.anisotropy = 4; if (THREE.SRGBColorSpace) t.colorSpace = THREE.SRGBColorSpace;
    return t;
}

/** Pelota visual: esfera perfecta con rotación física, estela, brillo y flash al recibir golpes. */
class BallVisual {
    constructor(scene) {
        this.R = BALL_CONFIG.gameRadius;
        const tex = createBallTexture();
        this.mat = new THREE.MeshStandardMaterial({map: tex, emissiveMap: tex, emissive: 0xffffff, emissiveIntensity: 0.12, roughness: 0.38, metalness: 0.05});
        this.mesh = new THREE.Mesh(new THREE.SphereGeometry(this.R, 48, 32), this.mat);
        scene.add(this.mesh);
        const gc = document.createElement('canvas'); gc.width = gc.height = 128; const g = gc.getContext('2d');
        const gr = g.createRadialGradient(64, 64, 4, 64, 64, 64); gr.addColorStop(0, 'rgba(255,255,255,0.9)'); gr.addColorStop(0.4, 'rgba(120,200,255,0.35)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
        g.fillStyle = gr; g.fillRect(0, 0, 128, 128);
        this.glow = new THREE.Sprite(new THREE.SpriteMaterial({map: new THREE.CanvasTexture(gc), transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, opacity: 0}));
        this.glow.scale.set(this.R * 5, this.R * 5, 1); scene.add(this.glow);
        this.N = 36; this.trailPos = new Float32Array(this.N * 3); this.trailCol = new Float32Array(this.N * 3); this.trailHist = [];
        const tg = new THREE.BufferGeometry(); tg.setAttribute('position', new THREE.BufferAttribute(this.trailPos, 3)); tg.setAttribute('color', new THREE.BufferAttribute(this.trailCol, 3));
        this.trail = new THREE.Line(tg, new THREE.LineBasicMaterial({vertexColors: true, transparent: true, opacity: 0.85, blending: THREE.AdditiveBlending, depthWrite: false}));
        this.trail.frustumCulled = false; scene.add(this.trail);
        this.q = new THREE.Quaternion(); this.flash = 0; this._dq = new THREE.Quaternion(); this._ax = new THREE.Vector3();
    }
    /** ball: {px,py,pz,vx,vy,vz,wx,wy,wz}. Integra la rotación visible a partir de la velocidad angular. */
    update(ball, dt) {
        this.mesh.position.set(ball.px, ball.py, ball.pz); this.glow.position.copy(this.mesh.position);
        const w = Math.hypot(ball.wx, ball.wy, ball.wz);
        if (w > 1e-4) { this._ax.set(ball.wx / w, ball.wy / w, ball.wz / w); this._dq.setFromAxisAngle(this._ax, w * dt); this.q.premultiply(this._dq).normalize(); this.mesh.quaternion.copy(this.q); }
        const sp = Math.hypot(ball.vx, ball.vy, ball.vz), k = Math.min(1, sp / 4500);
        this.flash = Math.max(0, this.flash - dt * 3.2);
        this.mat.emissiveIntensity = 0.12 + this.flash * 1.4;
        this.glow.material.opacity = Math.min(0.9, 0.12 + k * 0.5 + this.flash * 0.6);
        this.glow.material.color.setRGB(1, 1 - k * 0.45, 1 - k * 0.8);
        // estela
        this.trailHist.unshift([ball.px, ball.py, ball.pz]); if (this.trailHist.length > this.N) this.trailHist.pop();
        const show = sp > 1600, n = this.trailHist.length;
        for (let i = 0; i < this.N; i++) {
            const h = this.trailHist[Math.min(i, n - 1)], f = show ? (1 - i / this.N) * k : 0;
            this.trailPos[i * 3] = h[0]; this.trailPos[i * 3 + 1] = h[1]; this.trailPos[i * 3 + 2] = h[2];
            this.trailCol[i * 3] = f; this.trailCol[i * 3 + 1] = f * 0.7; this.trailCol[i * 3 + 2] = f * 0.35;
        }
        this.trail.geometry.attributes.position.needsUpdate = true; this.trail.geometry.attributes.color.needsUpdate = true;
    }
    hit(strength) { this.flash = Math.min(1, 0.35 + strength / 3500); }
    clearTrail() { this.trailHist = []; }
}

/** Efectos: chispas (partículas aditivas) y ondas de choque. */
class Effects {
    constructor(scene, camera) {
        this.camera = camera; this.max = 600; this.n = 0;
        this.pos = new Float32Array(this.max * 3); this.col = new Float32Array(this.max * 3);
        this.vel = new Float32Array(this.max * 3); this.life = new Float32Array(this.max); this.maxLife = new Float32Array(this.max); this.base = new Float32Array(this.max * 3);
        const g = new THREE.BufferGeometry();
        g.setAttribute('position', new THREE.BufferAttribute(this.pos, 3)); g.setAttribute('color', new THREE.BufferAttribute(this.col, 3));
        this.points = new THREE.Points(g, new THREE.PointsMaterial({size: 34, vertexColors: true, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, sizeAttenuation: true}));
        this.points.frustumCulled = false; scene.add(this.points);
        this.rings = [];
        for (let i = 0; i < 6; i++) {
            const m = new THREE.Mesh(new THREE.RingGeometry(0.82, 1, 48), new THREE.MeshBasicMaterial({color: 0xffffff, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide}));
            m.visible = false; m.userData = {t: 1, dur: 0.5, size: 400}; scene.add(m); this.rings.push(m);
        }
        this.ringIdx = 0; this.cursor = 0;
    }
    emit(x, y, z, vx, vy, vz, r, g, b, life) {
        const i = this.cursor; this.cursor = (this.cursor + 1) % this.max;
        this.pos[i * 3] = x; this.pos[i * 3 + 1] = y; this.pos[i * 3 + 2] = z; this.vel[i * 3] = vx; this.vel[i * 3 + 1] = vy; this.vel[i * 3 + 2] = vz;
        this.base[i * 3] = r; this.base[i * 3 + 1] = g; this.base[i * 3 + 2] = b; this.life[i] = life; this.maxLife[i] = life;
    }
    burst(x, y, z, count, speed, color, life) {
        const c = new THREE.Color(color);
        for (let i = 0; i < count; i++) {
            const th = Math.random() * Math.PI * 2, ph = Math.acos(2 * Math.random() - 1), s = speed * (0.35 + Math.random() * 0.65);
            this.emit(x, y, z, s * Math.sin(ph) * Math.cos(th), s * Math.cos(ph), s * Math.sin(ph) * Math.sin(th), c.r, c.g, c.b, (life || 0.8) * (0.6 + Math.random() * 0.6));
        }
    }
    ring(x, y, z, size, color, dur) {
        const m = this.rings[this.ringIdx++ % this.rings.length];
        m.position.set(x, y, z); m.userData.t = 0; m.userData.dur = dur || 0.5; m.userData.size = size; m.material.color.set(color); m.visible = true;
    }
    /** Golpe fuerte a la pelota: onda + chispas */
    ballHit(ball, strength) {
        const k = Math.min(1, strength / 3500);
        this.ring(ball.px, ball.py, ball.pz, 260 + 520 * k, 0xbfe6ff, 0.45);
        this.burst(ball.px, ball.py, ball.pz, Math.round(14 + 50 * k), 500 + 1400 * k, 0xffe6a0, 0.7);
    }
    update(dt) {
        for (let i = 0; i < this.max; i++) {
            if (this.life[i] <= 0) { this.col[i * 3] = this.col[i * 3 + 1] = this.col[i * 3 + 2] = 0; continue; }
            this.life[i] -= dt; const f = Math.max(0, this.life[i] / this.maxLife[i]);
            this.vel[i * 3 + 1] -= 500 * dt;
            this.pos[i * 3] += this.vel[i * 3] * dt; this.pos[i * 3 + 1] += this.vel[i * 3 + 1] * dt; this.pos[i * 3 + 2] += this.vel[i * 3 + 2] * dt;
            this.col[i * 3] = this.base[i * 3] * f; this.col[i * 3 + 1] = this.base[i * 3 + 1] * f; this.col[i * 3 + 2] = this.base[i * 3 + 2] * f;
        }
        this.points.geometry.attributes.position.needsUpdate = true; this.points.geometry.attributes.color.needsUpdate = true;
        this.rings.forEach(m => {
            const u = m.userData; if (u.t >= 1) { m.visible = false; return; }
            u.t = Math.min(1, u.t + dt / u.dur); const e = 1 - Math.pow(1 - u.t, 3);
            m.scale.setScalar(u.size * (0.15 + e)); m.material.opacity = 0.9 * (1 - u.t);
            m.quaternion.copy(this.camera.quaternion);
        });
    }
}
