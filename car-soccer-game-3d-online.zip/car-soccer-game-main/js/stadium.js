// Stadium Configuration (original conservada: colores de ambientación por estadio)
const STADIUM_CONFIG = {
    'neon-arena': {primaryColor: '#00d4ff', secondaryColor: '#b700ff'},
    'cyber-dome': {primaryColor: '#ff006e', secondaryColor: '#00d4ff'},
    'void-nexus': {primaryColor: '#b700ff', secondaryColor: '#00ff00'},
    'plasma-ridge': {primaryColor: '#ffbe0b', secondaryColor: '#ff006e'}
};

/**
 * Estadio 3D con las proporciones del campo estándar (8192 x 10240 x 2044 uu, porterías de 1786 x 642).
 * Suelo con césped artificial y líneas, paredes curvas en las esquinas y rampas laterales (transitables),
 * techo transparente, porterías con red, pads de turbo, marcadores sobre las porterías, gradas y focos.
 * Devuelve un objeto con update()/setScore()/setPads()/goalFlash()/cheer().
 */
function createStadium(stadiumType, scene, renderer) {
    const C = RL.C, cfg = STADIUM_CONFIG[stadiumType] || STADIUM_CONFIG['neon-arena'];
    const group = new THREE.Group(); scene.add(group);
    const BLUE = new THREE.Color(0x1f6bff), ORANGE = new THREE.Color(0xff7a14);
    const prim = new THREE.Color(cfg.primaryColor), sec = new THREE.Color(cfg.secondaryColor);
    const HW = C.HALF_W, HL = C.HALF_L, H = C.HEIGHT, R = C.FILLET_R, RC = C.CORNER_R;
    const S = {group, pads: [], padMeshes: []};

    // ---------- texturas
    function grassTexture() {
        const W = 2048, Hh = 2560, k = W / (2 * HW), cv = document.createElement('canvas'); cv.width = W; cv.height = Hh;
        const g = cv.getContext('2d'), X = x => (x + HW) * k, Y = z => (HL - z) * k;
        for (let i = 0; i < 20; i++) { g.fillStyle = i % 2 ? '#2f8f3e' : '#37a048'; g.fillRect(0, i * Hh / 20, W, Hh / 20 + 1); }   // franjas de corte
        for (let i = 0; i < 30000; i++) { g.fillStyle = Math.random() < 0.5 ? 'rgba(0,40,0,0.09)' : 'rgba(180,255,170,0.07)'; g.fillRect(Math.random() * W, Math.random() * Hh, 2, 3); }   // fibras
        g.strokeStyle = 'rgba(255,255,255,0.9)'; g.lineWidth = 7; g.fillStyle = 'rgba(255,255,255,0.9)';
        const line = (x1, z1, x2, z2) => { g.beginPath(); g.moveTo(X(x1), Y(z1)); g.lineTo(X(x2), Y(z2)); g.stroke(); };
        line(-HW + R, 0, HW - R, 0);
        g.beginPath(); g.arc(X(0), Y(0), 780 * k, 0, 7); g.stroke();
        g.beginPath(); g.arc(X(0), Y(0), 28 * k, 0, 7); g.fill();
        [-1, 1].forEach(s => {                                               // áreas de portería
            const z0 = s * (HL - R * 0.0), z1 = s * (HL - 1250);
            g.strokeRect(X(-1900), Y(Math.max(z0, z1)), 3800 * k, Math.abs(z0 - z1) * k);
            g.strokeRect(X(-1000), Y(Math.max(z0, s * (HL - 600))), 2000 * k, 600 * k);
            g.beginPath(); g.arc(X(0), Y(z1), 600 * k, s > 0 ? 0 : Math.PI, s > 0 ? Math.PI : Math.PI * 2, s < 0 ? false : false); g.stroke();
            [-1, 1].forEach(sx => { g.beginPath(); g.arc(X(sx * (HW - R)), Y(s * (HL - R)), 220 * k, 0, 7); g.stroke(); });
        });
        const t = new THREE.CanvasTexture(cv); t.anisotropy = 8; if (THREE.SRGBColorSpace) t.colorSpace = THREE.SRGBColorSpace; return t;
    }
    function gridTexture(alpha, line, cells) {
        const cv = document.createElement('canvas'); cv.width = cv.height = 256; const g = cv.getContext('2d');
        g.fillStyle = 'rgba(255,255,255,' + alpha + ')'; g.fillRect(0, 0, 256, 256);
        g.strokeStyle = 'rgba(255,255,255,' + line + ')'; g.lineWidth = 6;
        const s = 256 / cells; for (let i = 0; i <= cells; i++) { g.beginPath(); g.moveTo(i * s, 0); g.lineTo(i * s, 256); g.stroke(); g.beginPath(); g.moveTo(0, i * s); g.lineTo(256, i * s); g.stroke(); }
        const t = new THREE.CanvasTexture(cv); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.anisotropy = 4; return t;
    }

    // ---------- iluminación + entorno para reflejos
    scene.add(new THREE.HemisphereLight(0xcfe0ff, 0x242a3c, 0.85));
    const sun = new THREE.DirectionalLight(0xffffff, 0.9); sun.position.set(1500, 6000, 800); scene.add(sun);
    const lightB = new THREE.PointLight(0x2d7bff, 0.0, 4200, 1.6); lightB.position.set(0, 420, -5600); scene.add(lightB);
    const lightO = new THREE.PointLight(0xff8a1f, 0.0, 4200, 1.6); lightO.position.set(0, 420, 5600); scene.add(lightO);
    try {
        const env = new THREE.Scene(), sg = new THREE.SphereGeometry(100, 24, 12), cols = [];
        const pos = sg.attributes.position; for (let i = 0; i < pos.count; i++) { const y = pos.getY(i) / 100; const c = y > 0 ? new THREE.Color(0x8fb4ff).lerp(new THREE.Color(0xffffff), y * 0.6) : new THREE.Color(0x1b2a1c).lerp(new THREE.Color(0x0a0e18), -y); cols.push(c.r, c.g, c.b); }
        sg.setAttribute('color', new THREE.Float32BufferAttribute(cols, 3));
        env.add(new THREE.Mesh(sg, new THREE.MeshBasicMaterial({vertexColors: true, side: THREE.BackSide})));
        for (let i = 0; i < 6; i++) { const p = new THREE.Mesh(new THREE.BoxGeometry(40, 2, 40), new THREE.MeshBasicMaterial({color: 0xffffff})); p.position.set(Math.cos(i * 1.05) * 50, 80, Math.sin(i * 1.05) * 50); p.lookAt(0, 0, 0); env.add(p); }
        const pm = new THREE.PMREMGenerator(renderer); scene.environment = pm.fromScene(env, 0.04).texture; pm.dispose();
    } catch (e) { console.warn('Sin mapa de entorno:', e); }

    // ---------- suelo (rectángulo redondeado interior a las rampas)
    const inset = {x: HW - R, z: HL - R, r: RC - R};
    function roundedRect(hx, hz, r, seg) {
        const sh = new THREE.Shape(); sh.moveTo(-hx + r, -hz); sh.lineTo(hx - r, -hz); sh.absarc(hx - r, -hz + r, r, -Math.PI / 2, 0, false);
        sh.lineTo(hx, hz - r); sh.absarc(hx - r, hz - r, r, 0, Math.PI / 2, false); sh.lineTo(-hx + r, hz); sh.absarc(-hx + r, hz - r, r, Math.PI / 2, Math.PI, false);
        sh.lineTo(-hx, -hz + r); sh.absarc(-hx + r, -hz + r, r, Math.PI, Math.PI * 1.5, false); return new THREE.ShapeGeometry(sh, seg || 12);
    }
    const floorGeo = roundedRect(inset.x, inset.z, inset.r, 14); floorGeo.rotateX(-Math.PI / 2);   // (x,y)->(x,z) plano XZ, y=0
    { const p = floorGeo.attributes.position, uv = floorGeo.attributes.uv;
      // el rotateX(-π/2) pasa la y de la forma a -z; reconstruimos UV a partir de coordenadas del mundo
      for (let i = 0; i < p.count; i++) uv.setXY(i, (p.getX(i) + HW) / (2 * HW), 1 - (HL - p.getZ(i)) / (2 * HL) * 1 + 0); }
    const floor = new THREE.Mesh(floorGeo, new THREE.MeshStandardMaterial({map: grassTexture(), roughness: 0.92, metalness: 0}));
    floor.position.y = 0; group.add(floor);
    // fuera del estadio
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(60000, 60000), new THREE.MeshStandardMaterial({color: 0x0b0f1a, roughness: 1}));
    ground.rotation.x = -Math.PI / 2; ground.position.y = -6; group.add(ground);

    // ---------- paredes: barrido de un perfil (rampa → pared → rampa) a lo largo del contorno redondeado
    (function walls() {
        const cx = HW - RC, cz = HL - RC, path = [];   // {x,z,nx,nz,end,kind}
        const add = (x, z, ox, oz, end) => path.push({x, z, nx: -ox, nz: -oz, end});
        const straightX = (z, xs, oz) => xs.forEach(x => add(x, z, 0, oz, true));           // pared de fondo (z=±HL)
        const arc = (ccx, ccz, a0, a1, n) => { for (let i = 0; i <= n; i++) { const a = a0 + (a1 - a0) * i / n; add(ccx + Math.cos(a) * RC, ccz + Math.sin(a) * RC, Math.cos(a), Math.sin(a), false); } };
        const xs = [cx, 1900, 893, 0, -893, -1900, -cx];
        straightX(HL, xs, 1);
        arc(-cx, cz, Math.PI / 2, Math.PI, 14);
        for (let z = cz; z >= -cz - 1; z -= 662) add(-HW, z, -1, 0, false);
        arc(-cx, -cz, Math.PI, Math.PI * 1.5, 14);
        straightX(-HL, xs.slice().reverse(), -1);
        arc(cx, -cz, Math.PI * 1.5, Math.PI * 2, 14);
        for (let z = -cz; z <= cz + 1; z += 662) add(HW, z, 1, 0, false);
        arc(cx, cz, 0, Math.PI / 2, 14);
        // perfil (w = distancia hacia dentro, y = altura)
        const prof = [], N = 10;
        for (let i = 0; i <= N; i++) { const t = i / N * Math.PI / 2; prof.push([R - R * Math.sin(t), R - R * Math.cos(t)]); }
        [642, 900, 1200, 1524].forEach(y => prof.push([0, y]));
        for (let i = 1; i <= N; i++) { const t = i / N * Math.PI / 2; prof.push([R - R * Math.cos(t), H - R + R * Math.sin(t)]); }
        const P = path.length, Q = prof.length, pos = [], col = [], uv = [], idx = []; let dist = 0;
        for (let i = 0; i < P; i++) {
            const a = path[i]; if (i) dist += Math.hypot(a.x - path[i - 1].x, a.z - path[i - 1].z);
            for (let j = 0; j < Q; j++) {
                const w = prof[j][0], y = prof[j][1];
                const x = a.x + a.nx * w, z = a.z + a.nz * w; pos.push(x, y, z); uv.push(dist / 512, y / 512);
                const tz = Math.min(1, Math.max(0, (z + 1400) / 2800)), c = BLUE.clone().lerp(ORANGE, tz), dim = 0.55 + 0.45 * Math.min(1, y / 700);
                col.push(c.r * dim, c.g * dim, c.b * dim);
            }
        }
        for (let i = 0; i < P - 1; i++) for (let j = 0; j < Q - 1; j++) {
            const a = path[i], b = path[i + 1];
            if (a.end && b.end && Math.abs(Math.abs(a.z) - HL) < 1 && Math.abs(a.x) <= 893.5 && Math.abs(b.x) <= 893.5 && prof[j + 1][1] <= 642.5) continue;   // hueco de la portería
            const i0 = i * Q + j, i1 = (i + 1) * Q + j; idx.push(i0, i1, i0 + 1, i1, i1 + 1, i0 + 1);
        }
        // cierre del anillo
        for (let j = 0; j < Q - 1; j++) { const i0 = (P - 1) * Q + j, i1 = j; idx.push(i0, i1, i0 + 1, i1, i1 + 1, i0 + 1); }
        const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
        g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2)); g.setIndex(idx);
        const mat = new THREE.MeshBasicMaterial({vertexColors: true, map: gridTexture(0.5, 1.0, 4), transparent: true, opacity: 0.34, side: THREE.DoubleSide, depthWrite: false});
        const m = new THREE.Mesh(g, mat); m.renderOrder = 2; group.add(m); S.walls = m;
    })();
    // techo transparente
    { const g = roundedRect(HW - R, HL - R, RC - R, 12); g.rotateX(Math.PI / 2);
      const m = new THREE.Mesh(g, new THREE.MeshBasicMaterial({color: 0x8fb4ff, transparent: true, opacity: 0.05, side: THREE.DoubleSide, depthWrite: false})); m.position.y = H; m.renderOrder = 1; group.add(m); }

    // ---------- porterías
    S.goals = [];
    [-1, 1].forEach(sz => {
        const col = sz < 0 ? BLUE : ORANGE, gm = new THREE.Group(), gw = C.GOAL_HALF_W, gh = C.GOAL_H, gd = C.GOAL_DEPTH;
        const frameMat = new THREE.MeshStandardMaterial({color: col, emissive: col, emissiveIntensity: 1.1, roughness: 0.4});
        [-1, 1].forEach(sx => { const p = new THREE.Mesh(new THREE.CylinderGeometry(22, 22, gh, 12), frameMat); p.position.set(sx * gw, gh / 2, sz * HL); gm.add(p); });
        const bar = new THREE.Mesh(new THREE.CylinderGeometry(22, 22, gw * 2, 12), frameMat); bar.rotation.z = Math.PI / 2; bar.position.set(0, gh, sz * HL); gm.add(bar);
        const net = new THREE.MeshBasicMaterial({map: gridTexture(0.08, 0.9, 8), color: col.clone().lerp(new THREE.Color(0xffffff), 0.55), transparent: true, opacity: 0.8, side: THREE.DoubleSide, depthWrite: false});
        const mk = (w, h, x, y, z, ry, rx) => { const g = new THREE.PlaneGeometry(w, h); const m = new THREE.Mesh(g, net.clone()); m.material.map = net.map.clone(); m.material.map.needsUpdate = true; m.material.map.repeat.set(w / 450, h / 450); m.position.set(x, y, z); m.rotation.y = ry || 0; m.rotation.x = rx || 0; gm.add(m); };
        mk(gw * 2, gh, 0, gh / 2, sz * (HL + gd), 0, 0);                          // fondo
        [-1, 1].forEach(sx => mk(gd, gh, sx * gw, gh / 2, sz * (HL + gd / 2), Math.PI / 2, 0));   // laterales
        mk(gw * 2, gd, 0, gh, sz * (HL + gd / 2), 0, Math.PI / 2);                // techo de la red
        const gf = new THREE.Mesh(new THREE.PlaneGeometry(gw * 2, gd + R + 20), new THREE.MeshStandardMaterial({color: 0x1a2236, roughness: 0.8}));
        gf.rotation.x = -Math.PI / 2; gf.position.set(0, 0.5, sz * (HL - R / 2 + gd / 2 + 10)); gm.add(gf);
        group.add(gm); S.goals.push({light: sz < 0 ? lightB : lightO, frameMat, base: 1.1, flash: 0});
    });

    // ---------- pads de turbo
    const pads = RL.makePads();
    pads.forEach((p, i) => {
        const r = p.big ? 208 : 144, c = p.big ? new THREE.Color(0xffb020) : prim.clone().lerp(new THREE.Color(0xffffff), 0.35);
        const m = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.78, r * 0.78, 5, 6), new THREE.MeshStandardMaterial({color: c, emissive: c, emissiveIntensity: 1.3, roughness: 0.5}));
        m.position.set(p.x, 3, p.z); group.add(m);
        const rg = new THREE.Mesh(new THREE.RingGeometry(r * 0.82, r * 0.95, 6), new THREE.MeshBasicMaterial({color: c, transparent: true, opacity: 0.7, side: THREE.DoubleSide}));
        rg.rotation.x = -Math.PI / 2; rg.position.set(p.x, 6, p.z); group.add(rg);
        let beam = null; if (p.big) { beam = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.35, r * 0.35, 260, 10, 1, true), new THREE.MeshBasicMaterial({color: c, transparent: true, opacity: 0.22, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide})); beam.position.set(p.x, 135, p.z); group.add(beam); }
        S.padMeshes.push({m, rg, beam, big: p.big, active: true});
    });
    S.setPads = function (bits) {      // bits: cadena "0101.." (1 = inactivo)
        if (!bits) return;
        for (let i = 0; i < S.padMeshes.length; i++) {
            const off = bits[i] === '1', pm = S.padMeshes[i]; if (pm.active === !off) continue; pm.active = !off;
            pm.m.material.emissiveIntensity = off ? 0.05 : 1.3; pm.rg.material.opacity = off ? 0.12 : 0.7; if (pm.beam) pm.beam.visible = !off;
        }
    };

    // ---------- marcadores sobre las porterías
    S.boards = [];
    [-1, 1].forEach(sz => {
        const cv = document.createElement('canvas'); cv.width = 1024; cv.height = 256; const tex = new THREE.CanvasTexture(cv); if (THREE.SRGBColorSpace) tex.colorSpace = THREE.SRGBColorSpace;
        const board = new THREE.Mesh(new THREE.PlaneGeometry(2700, 675), new THREE.MeshBasicMaterial({map: tex, toneMapped: false}));
        board.position.set(0, 1330, sz * 5480); if (sz > 0) board.rotation.y = Math.PI; group.add(board);
        const frame = new THREE.Mesh(new THREE.BoxGeometry(2800, 775, 60), new THREE.MeshStandardMaterial({color: 0x0a0d16, roughness: 0.6, metalness: 0.5}));
        frame.position.set(0, 1330, sz * (5480 + 40)); group.add(frame);
        S.boards.push({cv, tex});
    });
    S.setScore = function (score, timeText, phase, ot) {
        S.boards.forEach(b => {
            const g = b.cv.getContext('2d'), W = 1024, Hh = 256;
            g.fillStyle = '#05070d'; g.fillRect(0, 0, W, Hh);
            g.fillStyle = '#16356b'; g.fillRect(0, 0, 360, Hh); g.fillStyle = '#7a3a08'; g.fillRect(W - 360, 0, 360, Hh);
            g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = '#fff';
            g.font = 'bold 150px Orbitron, Arial, sans-serif'; g.fillText(String(score[0]), 180, 135); g.fillText(String(score[1]), W - 180, 135);
            g.font = 'bold 96px Orbitron, Arial, sans-serif'; g.fillStyle = ot ? '#ff5050' : '#ffffff'; g.fillText(ot ? 'OT' : timeText, W / 2, 112);
            g.font = 'bold 34px Orbitron, Arial, sans-serif'; g.fillStyle = '#8ec5ff'; g.fillText('AZUL', 180, 30); g.fillStyle = '#ffb066'; g.fillText('NARANJA', W - 180, 30);
            g.fillStyle = '#9aa7c2'; g.font = '30px Orbitron, Arial, sans-serif'; g.fillText(phase === 'goal' ? '¡GOL!' : phase === 'ended' ? 'FIN' : '', W / 2, 212);
            b.tex.needsUpdate = true;
        });
    };
    S.setScore([0, 0], '5:00', 'countdown', false);

    // ---------- gradas con público, focos y tiras de luz
    const rnd = (() => { let s = 12345; return () => (s = (s * 16807) % 2147483647) / 2147483647; })();
    const stepMat = new THREE.MeshStandardMaterial({color: 0x151a28, roughness: 0.9});
    const seats = [];
    function stand(x0, z0, dirx, dirz, len, rows) {         // dir = hacia fuera; len a lo largo del lado
        for (let r = 0; r < rows; r++) {
            const h = 260 + r * 210, depth = 250, off = 240 + r * depth;
            const alongX = dirz !== 0;
            const w = alongX ? len : depth, d = alongX ? depth : len;
            const b = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), stepMat);
            b.position.set(x0 + dirx * off, h / 2, z0 + dirz * off); group.add(b);
            const n = Math.floor(len / 125);
            for (let i = 0; i < n; i++) { const a = -len / 2 + (i + 0.5) * len / n;
                seats.push([x0 + dirx * off + (alongX ? a : 0), h + 52, z0 + dirz * off + (alongX ? 0 : a)]); }
        }
    }
    stand(HW + 200, 0, 1, 0, 12400, 10); stand(-HW - 200, 0, -1, 0, 12400, 10);
    stand(0, HL + 1000, 0, 1, 11800, 10); stand(0, -HL - 1000, 0, -1, 11800, 10);
    const crowd = new THREE.InstancedMesh(new THREE.BoxGeometry(62, 104, 62), new THREE.MeshLambertMaterial({color: 0xffffff}), seats.length);
    const dm = new THREE.Object3D(), pal = [0x2d5bff, 0xff8a1f, 0xe8e8f0, 0x7a4cff, 0x30d0c8, 0xc0c8d8, 0xff4d6a];
    S.crowdBase = []; seats.forEach((s, i) => {
        dm.position.set(s[0], s[1], s[2]); dm.updateMatrix(); crowd.setMatrixAt(i, dm.matrix);
        const c = new THREE.Color(pal[Math.floor(rnd() * pal.length)]).multiplyScalar(0.55 + rnd() * 0.45); crowd.setColorAt(i, c); S.crowdBase.push(c);
    });
    crowd.instanceColor.needsUpdate = true; group.add(crowd); S.crowd = crowd; S.cheerT = 0; S.cheerTeam = 0;
    S.cheer = function (team) { S.cheerT = 4; S.cheerTeam = team; const c = new THREE.Color(team === 0 ? 0x3a78ff : 0xff8f2a);
        for (let i = 0; i < seats.length; i++) crowd.setColorAt(i, rnd() < 0.7 ? c.clone().multiplyScalar(0.6 + rnd() * 0.5) : S.crowdBase[i]); crowd.instanceColor.needsUpdate = true; };
    // focos (torres) y tiras de luz del techo
    const lampMat = new THREE.MeshBasicMaterial({color: 0xffffff});
    [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(s => {
        const x = s[0] * (HW + 1500), z = s[1] * (HL + 900);
        const pole = new THREE.Mesh(new THREE.CylinderGeometry(50, 80, 3600, 8), stepMat); pole.position.set(x, 1800, z); group.add(pole);
        const lamp = new THREE.Mesh(new THREE.BoxGeometry(900, 500, 60), lampMat); lamp.position.set(x, 3700, z); lamp.lookAt(0, 800, 0); group.add(lamp);
    });
    const stripMat = new THREE.MeshBasicMaterial({color: prim.clone().lerp(new THREE.Color(0xffffff), 0.6)});
    for (let i = -2; i <= 2; i++) { const b = new THREE.Mesh(new THREE.BoxGeometry(70, 14, 8600), stripMat); b.position.set(i * 1400, H - 6, 0); group.add(b); }
    for (let i = -3; i <= 3; i++) { const b = new THREE.Mesh(new THREE.BoxGeometry(6400, 14, 70), new THREE.MeshBasicMaterial({color: sec.clone().lerp(new THREE.Color(0xffffff), 0.5)})); b.position.set(0, H - 6, i * 1400); group.add(b); }

    S.goalFlash = function (team) { S.goals[team === 0 ? 1 : 0].flash = 3; S.cheer(team); };   // team que marca → portería rival
    S.update = function (dt) {
        S.goals.forEach(g => { g.flash = Math.max(0, g.flash - dt); const f = g.flash > 0 ? (0.5 + 0.5 * Math.sin(g.flash * 22)) : 0;
            g.light.intensity = f * 6; g.frameMat.emissiveIntensity = g.base + f * 3; });
        if (S.cheerT > 0) { S.cheerT -= dt; if (S.cheerT <= 0) { for (let i = 0; i < seats.length; i++) crowd.setColorAt(i, S.crowdBase[i]); crowd.instanceColor.needsUpdate = true; } }
        S.padMeshes.forEach(p => { if (p.beam && p.active) p.beam.rotation.y += dt; });
    };
    S.dispose = function () { scene.remove(group); scene.remove(sun); };
    return S;
}
