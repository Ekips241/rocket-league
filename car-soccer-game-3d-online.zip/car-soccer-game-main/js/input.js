const inputState = {
    keys: {},
    mouse: {x: 0, y: 0, pressed: false},
    touch: {x: 0, y: 0, pressed: false}
};
let _camToggleRequested = false, _tabHeld = false;

document.addEventListener('keydown', (e) => {
    const k = e.key.toLowerCase();
    if (['arrowup', 'arrowdown', 'arrowleft', 'arrowright', ' ', 'tab'].includes(k) && gameState && gameState.isPlaying) e.preventDefault();
    if (!e.repeat) {
        if (k === 'c') _camToggleRequested = true;
        if (k === 'tab') _tabHeld = true;
    }
    inputState.keys[k] = true;
    if (e.key === 'Escape') pauseGame();
});

document.addEventListener('keyup', (e) => {
    const k = e.key.toLowerCase();
    inputState.keys[k] = false;
    if (k === 'tab') _tabHeld = false;
});
window.addEventListener('blur', () => { inputState.keys = {}; _tabHeld = false; inputState.mouse.pressed = false; });

document.addEventListener('mousemove', (e) => {
    inputState.mouse.x = e.clientX;
    inputState.mouse.y = e.clientY;
});

document.addEventListener('mousedown', (e) => {
    if (e.target && e.target.id === 'game-canvas') inputState.mouse.pressed = true;
});

document.addEventListener('mouseup', () => {
    inputState.mouse.pressed = false;
});

document.addEventListener('touchstart', (e) => {
    inputState.touch.x = e.touches[0].clientX;
    inputState.touch.y = e.touches[0].clientY;
    inputState.touch.pressed = true;
});

document.addEventListener('touchmove', (e) => {
    inputState.touch.x = e.touches[0].clientX;
    inputState.touch.y = e.touches[0].clientY;
});

document.addEventListener('touchend', () => {
    inputState.touch.pressed = false;
});

/**
 * Lee el teclado y devuelve el control del coche:
 *  W/↑ acelerar (en el aire: morro abajo) · S/↓ marcha atrás/freno (aire: morro arriba) · A/D o ←/→ dirección/guiñada
 *  ESPACIO salto (pulsar de nuevo en el aire + dirección = voltereta) · SHIFT/E/clic turbo
 *  Q o CTRL derrape (freno de mano) · Z/X alabeo en el aire · C cambia cámara · TAB lista de jugadores
 */
function getControls() {
    const k = inputState.keys, b = (...n) => n.some(x => k[x]);
    const fwd = b('w', 'arrowup') ? 1 : 0, back = b('s', 'arrowdown') ? 1 : 0, r = b('d', 'arrowright') ? 1 : 0, l = b('a', 'arrowleft') ? 1 : 0;
    return {
        throttle: fwd - back, pitch: fwd - back, steer: r - l,
        roll: (b('x') ? 1 : 0) - (b('z') ? 1 : 0),
        jump: b(' ', 'space'), boost: b('shift', 'e') || inputState.mouse.pressed, handbrake: b('q', 'control')
    };
}
function consumeCameraToggle() { const v = _camToggleRequested; _camToggleRequested = false; return v; }
function isTabHeld() { return _tabHeld; }

// (conservadas por compatibilidad: el control ahora se lee cada fotograma con getControls())
function handleGameInput(event) {}
function handleGameInputUp(event) {}
