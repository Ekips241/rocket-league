/**
 * carmodel.js — Modelo 3D ORIGINAL inspirado en el Fennec (carrocería cuadrada y compacta, capó corto,
 * techo plano, cristales oscuros). No usa ningún recurso de Rocket League: todo se genera con geometría propia.
 * Coordenadas locales: X = derecha, Y = arriba, Z = atrás (el frente apunta a -Z). Origen = centro de masa.
 */
(function (root) {
    const T = THREE;
    const FINISHES = {
        gloss:  {metalness: 0.25, roughness: 0.22, clearcoat: 1.0, clearcoatRoughness: 0.08},
        matte:  {metalness: 0.0,  roughness: 0.88, clearcoat: 0.0, clearcoatRoughness: 0.5},
        metal:  {metalness: 0.92, roughness: 0.26, clearcoat: 0.3, clearcoatRoughness: 0.2},
        pearl:  {metalness: 0.45, roughness: 0.3,  clearcoat: 1.0, clearcoatRoughness: 0.05}
    };
    const DEFAULT_LOOK = {c1: '#00d4ff', c2: '#101828', wheel: '#222222', finish: 'gloss', type: 'fennec'};

    // perfil lateral (f = distancia hacia delante, y = altura) extruido a lo ancho
    function extrude(pts, width, bevel) {
        const sh = new T.Shape();
        pts.forEach((p, i) => i ? sh.lineTo(p[0], p[1]) : sh.moveTo(p[0], p[1]));
        sh.closePath();
        const g = new T.ExtrudeGeometry(sh, {depth: width, bevelEnabled: true, bevelThickness: bevel, bevelSize: bevel, bevelSegments: 2, curveSegments: 1});
        g.translate(0, 0, -width / 2);
        g.rotateY(Math.PI / 2);                 // x del perfil → -Z (frente), extrusión → X
        return g;
    }
    function box(w, h, d, mat, x, y, z) {
        const m = new T.Mesh(new T.BoxGeometry(w, h, d), mat); m.position.set(x, y, z); return m;
    }
    function paint(mat, color, finish) {
        mat.color.set(color);
        const f = FINISHES[finish] || FINISHES.gloss;
        mat.metalness = f.metalness; mat.roughness = f.roughness;
        if ('clearcoat' in mat) { mat.clearcoat = f.clearcoat; mat.clearcoatRoughness = f.clearcoatRoughness; }
        mat.needsUpdate = true;
    }

    function buildCarModel(look) {
        look = Object.assign({}, DEFAULT_LOOK, look || {});
        const root3 = new T.Group();
        const mats = {
            body: new T.MeshPhysicalMaterial({color: look.c1}),
            accent: new T.MeshPhysicalMaterial({color: look.c2}),
            glass: new T.MeshStandardMaterial({color: 0x070b12, roughness: 0.05, metalness: 0.85, emissive: 0x03060c}),
            dark: new T.MeshStandardMaterial({color: 0x0d0f14, roughness: 0.7, metalness: 0.2}),
            tire: new T.MeshStandardMaterial({color: 0x111214, roughness: 0.95}),
            rim: new T.MeshStandardMaterial({color: look.wheel, roughness: 0.35, metalness: 0.85}),
            chrome: new T.MeshStandardMaterial({color: 0xb8bcc4, roughness: 0.2, metalness: 1.0}),
            head: new T.MeshStandardMaterial({color: 0xfff6d8, emissive: 0xfff0b8, emissiveIntensity: 2.2}),
            tail: new T.MeshStandardMaterial({color: 0xff1a1a, emissive: 0xff0a0a, emissiveIntensity: 2.0}),
            team: new T.MeshStandardMaterial({color: 0xffffff, emissive: 0xffffff, emissiveIntensity: 1.6})
        };
        paint(mats.body, look.c1, look.finish); paint(mats.accent, look.c2, look.finish);
        const B = new T.Group(); root3.add(B);

        // carrocería inferior: frontal rectangular, capó corto y plano, zaga vertical
        B.add(new T.Mesh(extrude([[-50, -3], [66, -3], [68, 2], [68, 11], [54, 14], [28, 15], [-8, 16], [-50, 17]], 84, 1.2), mats.body));
        // cabina (cristales oscuros) + techo plano
        B.add(new T.Mesh(extrude([[-44, 15], [26, 15], [8, 30], [-34, 30]], 70, 0.6), mats.glass));
        B.add(box(71, 2.4, 42, mats.body, 0, 31.2, 13));
        [-1, 1].forEach(s => {                                            // montantes B/C y A
            B.add(box(2.6, 15, 4, mats.body, s * 35.4, 22.5, 2));
            B.add(box(2.6, 15, 4, mats.body, s * 35.4, 22.5, 36));
        });
        // frontal: parrilla, splitter, faros
        B.add(box(36, 6, 2, mats.dark, 0, 5, -68.8));
        B.add(box(82, 2.2, 12, mats.accent, 0, -3.4, -64));
        [-1, 1].forEach(s => { B.add(box(15, 5, 2.2, mats.head, s * 27, 8.4, -68.6)); B.add(box(4, 5, 1.6, mats.head, s * 40.6, 8.4, -66)); });
        // trasera: luces, difusor, alerón tipo "ducktail", escapes
        [-1, 1].forEach(s => B.add(box(17, 5.5, 2.2, mats.tail, s * 27, 11, 50.8)));
        B.add(box(30, 1.6, 2.2, mats.tail, 0, 11, 50.8));
        B.add(box(78, 2.6, 8, mats.dark, 0, -3, 46));
        B.add(box(82, 2.4, 9, mats.accent, 0, 19.2, 45));
        [-1, 1].forEach(s => { const e = new T.Mesh(new T.CylinderGeometry(3, 3, 7, 12), mats.chrome); e.rotation.x = Math.PI / 2; e.position.set(s * 16, -1, 52); B.add(e); });
        // detalles: retrovisores, franjas, luz de equipo
        [-1, 1].forEach(s => {
            B.add(box(6, 3.2, 5, mats.accent, s * 43, 21, -12));
            B.add(box(0.8, 4, 104, mats.accent, s * 42.3, 5.5, -2));
        });
        B.add(box(14, 0.5, 40, mats.accent, 0, 15.6, -46));
        B.add(box(14, 0.5, 42, mats.accent, 0, 32.5, 13));
        const teamBar = box(26, 1.4, 3, mats.team, 0, 33.2, 28); B.add(teamBar);
        // arcos de rueda
        const wheels = [];
        const A = [[-37, -40], [37, -40], [-37, 40], [37, 40]];
        A.forEach((a, i) => {
            const arch = new T.Mesh(new T.TorusGeometry(16.2, 1.9, 6, 14, Math.PI), mats.dark);
            arch.rotation.y = Math.PI / 2; arch.position.set(Math.sign(a[0]) * 41.5, -6, a[1]); B.add(arch);
            // rueda: pivote (suspensión) → dirección → giro
            const pivot = new T.Group(); pivot.position.set(a[0] + Math.sign(a[0]) * 2, -6, a[1]);
            const steer = new T.Group(); const spin = new T.Group();
            const tire = new T.Mesh(new T.CylinderGeometry(12.5, 12.5, 11, 22), mats.tire); tire.rotation.z = Math.PI / 2; spin.add(tire);
            const rim = new T.Mesh(new T.CylinderGeometry(8.6, 8.6, 11.6, 16), mats.rim); rim.rotation.z = Math.PI / 2; spin.add(rim);
            for (let k = 0; k < 3; k++) { const sp = box(12.4, 15.5, 1.7, mats.rim, 0, 0, 0); sp.rotation.x = k * Math.PI / 3; spin.add(sp); }
            const cap = new T.Mesh(new T.CylinderGeometry(2.6, 2.6, 12.6, 10), mats.chrome); cap.rotation.z = Math.PI / 2; spin.add(cap);
            steer.add(spin); pivot.add(steer); root3.add(pivot);
            // amortiguador visible (se estira con la suspensión)
            const strut = new T.Mesh(new T.CylinderGeometry(1.4, 1.4, 1, 6), mats.chrome); root3.add(strut);
            wheels.push({pivot, steer, spin, strut, sx: Math.sign(a[0]), front: i < 2, ax: a[0], az: a[1]});
        });
        // llamas del turbo
        const flames = new T.Group();
        const flameMatO = new T.MeshBasicMaterial({color: 0xff7a1a, transparent: true, opacity: 0.85, blending: T.AdditiveBlending, depthWrite: false});
        const flameMatB = new T.MeshBasicMaterial({color: 0x8fd8ff, transparent: true, opacity: 0.9, blending: T.AdditiveBlending, depthWrite: false});
        [-1, 1].forEach(s => {
            [[flameMatO, 5.2, 46], [flameMatB, 2.8, 26]].forEach(f => {
                const g = new T.ConeGeometry(f[1], f[2], 10, 1, true); g.rotateX(Math.PI / 2); g.translate(0, 0, f[2] / 2);
                const m = new T.Mesh(g, f[0]); m.position.set(s * 16, -1, 55); flames.add(m);
            });
        });
        flames.visible = false; root3.add(flames);
        root3.userData = {mats, wheels, flames, teamBar, look};
        root3.traverse(o => { if (o.isMesh) { o.matrixAutoUpdate = true; } });
        return root3;
    }

    /** Aplica colores/acabado (personalización) a un modelo ya construido. */
    function applyCarLook(model, look) {
        look = Object.assign({}, DEFAULT_LOOK, look || {});
        const m = model.userData.mats;
        paint(m.body, look.c1, look.finish); paint(m.accent, look.c2, look.finish);
        m.rim.color.set(look.wheel); model.userData.look = look;
    }
    function setTeamColor(model, team) {
        const c = team === 0 ? 0x2d7bff : 0xff8a1f, t = model.userData.mats.team;
        t.color.set(c); t.emissive.set(c);
    }
    /** Anima ruedas, suspensión y llamas. car: {steerVis, spin, wheels:[{drop}], boosting} */
    function updateCarModel(model, car, time) {
        const W = model.userData.wheels;
        for (let i = 0; i < 4; i++) {
            const w = W[i], drop = car.wheels && car.wheels[i] ? car.wheels[i].drop : 6;
            const y = -drop;
            w.pivot.position.y = y;
            w.steer.rotation.y = w.front ? -car.steerVis * 0.45 : 0;
            w.spin.rotation.x = -car.spin;
            const top = 3, len = Math.max(2, top - y);
            w.strut.position.set(w.ax * 0.92, (top + y) / 2, w.az); w.strut.scale.set(1, len, 1);
        }
        const f = model.userData.flames;
        f.visible = !!car.boosting;
        if (car.boosting) { const k = 0.85 + 0.3 * Math.sin(time * 60) + 0.1 * Math.random(); f.scale.set(1, 1, k); }
    }
    function makeNameTag(name, color) {
        const c = document.createElement('canvas'); c.width = 256; c.height = 64; const x = c.getContext('2d');
        x.fillStyle = 'rgba(5,8,17,0.65)'; x.fillRect(0, 8, 256, 48); x.strokeStyle = color; x.lineWidth = 3; x.strokeRect(2, 10, 252, 44);
        x.fillStyle = '#fff'; x.font = 'bold 28px Orbitron, Arial, sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(name, 128, 33);
        const t = new T.CanvasTexture(c); const s = new T.Sprite(new T.SpriteMaterial({map: t, transparent: true, depthWrite: false, depthTest: false}));
        s.scale.set(120, 30, 1); s.position.set(0, 85, 0); s.renderOrder = 10; return s;
    }
    root.buildCarModel = buildCarModel; root.applyCarLook = applyCarLook; root.updateCarModel = updateCarModel;
    root.setCarTeamColor = setTeamColor; root.makeNameTag = makeNameTag; root.DEFAULT_LOOK = DEFAULT_LOOK; root.CAR_FINISHES = FINISHES;
})(window);
