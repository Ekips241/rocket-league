// Car Configurations (originales conservadas) + física de coche tipo Rocket League
const CAR_CONFIGS = {
    'fennec': {speed: 7, armor: 7, boost: 10},
    'speed-demon': {speed: 9, armor: 4, boost: 12},
    'tank-master': {speed: 5, armor: 9, boost: 8},
    'balanced-rider': {speed: 7, armor: 7, boost: 10},
    'agile-flash': {speed: 8, armor: 6, boost: 11}
};

function getCarStats(carType) {
    return CAR_CONFIGS[carType] || CAR_CONFIGS['fennec'];
}

/**
 * CarBody: cuerpo rígido con 4 ruedas con suspensión independiente (muelle + amortiguador),
 * conducción en suelo/paredes/techo, control en el aire, salto, doble salto, volteretas y turbo.
 * Unidades: uu y segundos (ver shared/rlcore.js). Eje local: X=derecha, Y=arriba, Z=atrás (el frente es -Z).
 */
(function (root) {
    const RLc = (typeof RL !== 'undefined') ? RL : require('../shared/rlcore.js');
    const C = RLc.C;
    const _c = {d: 0, nx: 0, ny: 0, nz: 0};
    const P = {
        wheelR: 12.5, travel: 14, k: 3650, damp: 480,
        // anclajes de rueda (local): delanteras z<0
        anchors: [[-36, 0, -40], [36, 0, -40], [-36, 0, 40], [36, 0, 40]],
        Ix: 228000, Iy: 314000, Iz: 125000,
        steerK: [[0, 0.0069], [500, 0.00398], [1000, 0.00235], [1500, 0.00138], [1750, 0.0011], [2300, 0.00089]],
        boostAccel: 991.667, boostUse: 33.33, jumpImpulse: 292, jumpHold: 1458, flipImpulse: 500
    };
    function steerCurv(sp) {
        const t = P.steerK;
        if (sp <= 0) return t[0][1];
        for (let i = 1; i < t.length; i++) if (sp <= t[i][0]) return t[i - 1][1] + (t[i][1] - t[i - 1][1]) * (sp - t[i - 1][0]) / (t[i][0] - t[i - 1][0]);
        return t[t.length - 1][1];
    }

    class CarBody {
        constructor(opts) {
            opts = opts || {};
            this.id = opts.id || 'local'; this.team = opts.team || 0;
            const st = getCarStats(opts.type);
            this.accelMul = 0.85 + 0.03 * st.speed;
            this.px = 0; this.py = 18.5; this.pz = 0; this.vx = this.vy = this.vz = 0;
            this.q = [0, 0, 0, 1]; this.wx = this.wy = this.wz = 0;
            this.boost = 33; this.steerVis = 0; this.spin = 0;
            this.wheels = [0, 1, 2, 3].map(() => ({contact: false, drop: 14, comp: 0}));
            this.reset(0, 0, 0);
        }
        reset(x, z, yaw) {
            this.px = x; this.py = 18.5; this.pz = z; this.vx = this.vy = this.vz = 0; this.wx = this.wy = this.wz = 0;
            this.q = RLc.quatFromYaw(yaw); RLc.quatAxes(this.q, this);
            this.airTime = 0; this.hasFlip = true; this.jumped = false; this.jumpHold = 0; this.flipT = 0; this.noGround = 0;
            this._jumpPrev = false; this.onGround = true; this.boosting = false; this.handbrake = false; this.nGround = 4;
        }
        /** Avanza la simulación dt segundos con el input {throttle,steer,pitch,roll,jump,boost,handbrake} */
        step(dt, inp) {
            RLc.quatAxes(this.q, this);
            const s = this, m = C.CAR_MASS;
            s.noGround = Math.max(0, s.noGround - dt);
            // ---- 1. suspensión por rueda
            let g = 0, nx = 0, ny = 0, nz = 0;
            for (let i = 0; i < 4; i++) {
                const a = P.anchors[i], w = s.wheels[i];
                const rx = s.rx * a[0] + s.ux * a[1] + s.bx * a[2], ry = s.ry * a[0] + s.uy * a[1] + s.by * a[2], rz = s.rz * a[0] + s.uz * a[1] + s.bz * a[2];
                RLc.arenaContact(s.px + rx, s.py + ry, s.pz + rz, _c);
                const rest = P.wheelR + P.travel, comp = Math.min(rest - _c.d, P.travel + 14);
                if (comp > 0 && _c.d > -40) {
                    w.contact = true; w.comp = comp; w.drop = Math.max(0, _c.d - P.wheelR);
                    // velocidad del punto de anclaje a lo largo de la normal
                    const pvx = s.vx + (s.wy * rz - s.wz * ry), pvy = s.vy + (s.wz * rx - s.wx * rz), pvz = s.vz + (s.wx * ry - s.wy * rx);
                    const vn = pvx * _c.nx + pvy * _c.ny + pvz * _c.nz;
                    let F = P.k * comp - P.damp * vn; if (F < 0) F = 0; if (F > 60000) F = 60000;
                    const fx = _c.nx * F, fy = _c.ny * F, fz = _c.nz * F;
                    s.vx += fx / m * dt; s.vy += fy / m * dt; s.vz += fz / m * dt;
                    const tx = ry * fz - rz * fy, ty = rz * fx - rx * fz, tz = rx * fy - ry * fx;
                    const ar = (tx * s.rx + ty * s.ry + tz * s.rz) / P.Ix, au = (tx * s.ux + ty * s.uy + tz * s.uz) / P.Iy, ab = (tx * s.bx + ty * s.by + tz * s.bz) / P.Iz;
                    s.wx += (s.rx * ar + s.ux * au + s.bx * ab) * dt; s.wy += (s.ry * ar + s.uy * au + s.by * ab) * dt; s.wz += (s.rz * ar + s.uz * au + s.bz * ab) * dt;
                    if (s.noGround <= 0) { g++; nx += _c.nx; ny += _c.ny; nz += _c.nz; }
                } else { w.contact = false; w.comp = 0; w.drop = P.travel; }
            }
            s.nGround = g;
            s.onGround = g >= 2;
            s.handbrake = !!inp.handbrake;
            s.vy -= C.GRAVITY * dt;
            const boosting = !!inp.boost && s.boost > 0;
            s.boosting = boosting;
            if (s.onGround) this._ground(dt, inp, nx, ny, nz, g, boosting); else this._air(dt, inp, boosting);
            // ---- salto / doble salto / voltereta
            if (s.onGround) { s.airTime = 0; s.hasFlip = true; s.flipT = 0; if (!inp.jump) s.jumped = false; } else s.airTime += dt;
            const edge = !!inp.jump && !s._jumpPrev; s._jumpPrev = !!inp.jump;
            if (edge) {
                if (s.onGround) {
                    s.vx += s.ux * P.jumpImpulse; s.vy += s.uy * P.jumpImpulse; s.vz += s.uz * P.jumpImpulse;
                    s.jumped = true; s.jumpHold = 0.2; s.noGround = 0.12; s.hasFlip = true; s.onGround = false;
                } else if (s.hasFlip && s.airTime < 1.25 && s.flipT <= 0) this._flip(inp);
            }
            if (inp.jump && s.jumpHold > 0) { s.vx += s.ux * P.jumpHold * dt; s.vy += s.uy * P.jumpHold * dt; s.vz += s.uz * P.jumpHold * dt; s.jumpHold -= dt; } else s.jumpHold = 0;
            if (s.flipT > 0) s.flipT -= dt;
            // ---- límite de velocidad, integración
            const sp = Math.sqrt(s.vx * s.vx + s.vy * s.vy + s.vz * s.vz);
            if (sp > C.CAR_MAX_SPEED) { const k = C.CAR_MAX_SPEED / sp; s.vx *= k; s.vy *= k; s.vz *= k; }
            s.px += s.vx * dt; s.py += s.vy * dt; s.pz += s.vz * dt;
            const q = s.q, a = s.wx, b = s.wy, c = s.wz, h = 0.5 * dt;
            const qx = q[0] + h * (a * q[3] + b * q[2] - c * q[1]), qy = q[1] + h * (b * q[3] + c * q[0] - a * q[2]),
                  qz = q[2] + h * (c * q[3] + a * q[1] - b * q[0]), qw = q[3] + h * (-a * q[0] - b * q[1] - c * q[2]);
            const ql = Math.sqrt(qx * qx + qy * qy + qz * qz + qw * qw) || 1;
            s.q = [qx / ql, qy / ql, qz / ql, qw / ql];
            RLc.quatAxes(s.q, s);
            this._bodyCollide();
            // ---- turbo (consumo) y visual
            if (boosting) s.boost = Math.max(0, s.boost - P.boostUse * dt);
            s.steerVis += ((inp.steer || 0) - s.steerVis) * Math.min(1, dt * 14);
            const fv = -(s.vx * s.bx + s.vy * s.by + s.vz * s.bz);
            s.spin += (fv / 40) * dt;
        }
        _ground(dt, inp, nx, ny, nz, g, boosting) {
            const s = this;
            const nl = Math.sqrt(nx * nx + ny * ny + nz * nz) || 1; nx /= nl; ny /= nl; nz /= nl;
            // forward tangente
            let fx = -s.bx, fy = -s.by, fz = -s.bz; const fd = fx * nx + fy * ny + fz * nz;
            fx -= nx * fd; fy -= ny * fd; fz -= nz * fd; const fl = Math.sqrt(fx * fx + fy * fy + fz * fz) || 1; fx /= fl; fy /= fl; fz /= fl;
            const rx = fy * nz - fz * ny, ry = fz * nx - fx * nz, rz = fx * ny - fy * nx;   // derecha = f × n
            const vf = s.vx * fx + s.vy * fy + s.vz * fz, vl = s.vx * rx + s.vy * ry + s.vz * rz, sp = Math.abs(vf);
            const th = inp.throttle || 0, hb = !!inp.handbrake;
            let acc = 0;
            if (th !== 0) {
                if (th * vf >= -5 || sp < 5) { if (sp < 1410) acc = th * (1600 - 1440 * sp / 1400) * s.accelMul; }
                else acc = th * 3500;
            } else if (!hb) acc = -Math.sign(vf) * Math.min(525, sp / dt);
            if (boosting) acc += P.boostAccel;
            s.vx += fx * acc * dt; s.vy += fy * acc * dt; s.vz += fz * acc * dt;
            // agarre lateral (derrape con freno de mano)
            const grip = hb ? 1.4 : 22, kk = 1 - Math.exp(-grip * dt);
            s.vx -= rx * vl * kk; s.vy -= ry * vl * kk; s.vz -= rz * vl * kk;
            if (hb) { const br = Math.min(300, sp / dt); s.vx -= fx * Math.sign(vf) * br * dt; s.vy -= fy * Math.sign(vf) * br * dt; s.vz -= fz * Math.sign(vf) * br * dt; }
            // dirección: velocidad angular de guiñada según curvatura dependiente de la velocidad
            const target = -(inp.steer || 0) * steerCurv(sp) * vf * (hb ? 1.7 : 1);
            const wn = s.wx * nx + s.wy * ny + s.wz * nz, kb = 1 - Math.exp(-12 * dt);
            s.wx += nx * (target - wn) * kb; s.wy += ny * (target - wn) * kb; s.wz += nz * (target - wn) * kb;
            // alinear el coche con la superficie (permite subir paredes)
            const ax = s.uy * nz - s.uz * ny, ay = s.uz * nx - s.ux * nz, az = s.ux * ny - s.uy * nx;
            const wnn = s.wx * nx + s.wy * ny + s.wz * nz;
            const px = s.wx - nx * wnn, py = s.wy - ny * wnn, pz = s.wz - nz * wnn, ka = 1 - Math.exp(-14 * dt);
            s.wx += (ax * 9 - px) * ka; s.wy += (ay * 9 - py) * ka; s.wz += (az * 9 - pz) * ka;
            // fuerza de adherencia + eliminar velocidad hacia la superficie conservando velocidad tangencial
            if (g >= 3) { s.vx -= nx * 325 * dt; s.vy -= ny * 325 * dt; s.vz -= nz * 325 * dt; }
            const vn = s.vx * nx + s.vy * ny + s.vz * nz;
            if (vn < 0) {
                const v0 = Math.sqrt(s.vx * s.vx + s.vy * s.vy + s.vz * s.vz);
                s.vx -= nx * vn; s.vy -= ny * vn; s.vz -= nz * vn;
                const v1 = Math.sqrt(s.vx * s.vx + s.vy * s.vy + s.vz * s.vz) || 1, k = Math.min(1.04, v0 / v1);
                s.vx *= k; s.vy *= k; s.vz *= k;
            }
        }
        _air(dt, inp, boosting) {
            const s = this;
            if (boosting) { s.vx -= s.bx * P.boostAccel * dt; s.vy -= s.by * P.boostAccel * dt; s.vz -= s.bz * P.boostAccel * dt; }
            if (s.flipT > 0) return;       // durante la voltereta no hay control
            // velocidades angulares locales actuales
            let lr = s.wx * s.rx + s.wy * s.ry + s.wz * s.rz, lu = s.wx * s.ux + s.wy * s.uy + s.wz * s.uz, lb = s.wx * s.bx + s.wy * s.by + s.wz * s.bz;
            const pit = inp.pitch || 0, yaw = inp.steer || 0, rol = inp.roll || 0, acc = 16 * dt, max = 5.5;
            const approach = (cur, tg, hasInput) => hasInput ? cur + Math.max(-acc, Math.min(acc, tg - cur)) : cur * Math.exp(-2.8 * dt);
            lr = approach(lr, -pit * max, pit !== 0);          // W = morro abajo
            lu = approach(lu, -yaw * max, yaw !== 0);          // D = guiñada a la derecha
            lb = approach(lb, -rol * max, rol !== 0);          // eje Z local = atrás
            s.wx = s.rx * lr + s.ux * lu + s.bx * lb; s.wy = s.ry * lr + s.uy * lu + s.by * lb; s.wz = s.rz * lr + s.uz * lu + s.bz * lb;
        }
        _flip(inp) {
            const s = this, pit = inp.pitch || 0, st = inp.steer || 0;
            s.hasFlip = false;
            if (Math.abs(pit) < 0.5 && Math.abs(st) < 0.5) {            // doble salto
                s.vx += s.ux * P.jumpImpulse; s.vy += s.uy * P.jumpImpulse; s.vz += s.uz * P.jumpImpulse; return;
            }
            const l = Math.sqrt(pit * pit + st * st);
            const dp = pit / l, ds = st / l;
            // direcciones horizontales del coche
            let fx = -s.bx, fz = -s.bz, fl = Math.sqrt(fx * fx + fz * fz) || 1; fx /= fl; fz /= fl;
            const RX = -fz, RZ = fx;   // derecha horizontal = adelante × arriba
            s.vx += (fx * dp + RX * ds) * P.flipImpulse; s.vz += (fz * dp + RZ * ds) * P.flipImpulse;
            const om = 10.5;
            // eje: -derecha*pitch + adelante*alabeo
            s.wx = (-s.rx * dp - s.bx * ds) * om; s.wy = (-s.ry * dp - s.by * ds) * om; s.wz = (-s.rz * dp - s.bz * ds) * om;
            s.flipT = 0.6;
        }
        /** Colisión de las 8 esquinas de la hitbox con la arena (techo, paredes, aterrizaje sobre el techo...) */
        _bodyCollide() {
            const s = this, H = C.HB;
            for (let ix = -1; ix <= 1; ix += 2) for (let iy = -1; iy <= 1; iy += 2) for (let iz = -1; iz <= 1; iz += 2) {
                const lx = ix * H.x, ly = C.HB_OFF_UP + iy * H.y, lz = -C.HB_OFF_FWD + iz * H.z;
                const wx = s.px + s.rx * lx + s.ux * ly + s.bx * lz, wy = s.py + s.ry * lx + s.uy * ly + s.by * lz, wz = s.pz + s.rz * lx + s.uz * ly + s.bz * lz;
                RLc.arenaContact(wx, wy, wz, _c);
                if (_c.d < 0) {
                    s.px -= _c.nx * _c.d; s.py -= _c.ny * _c.d; s.pz -= _c.nz * _c.d;
                    const vn = s.vx * _c.nx + s.vy * _c.ny + s.vz * _c.nz;
                    if (vn < 0) { s.vx -= _c.nx * vn * 1.25; s.vy -= _c.ny * vn * 1.25; s.vz -= _c.nz * vn * 1.25; }
                }
            }
        }
        /** Colisión entre coches (aproximación con tres esferas). `o` = otro coche (estado actual). */
        collideCar(o) {
            const R = 42, offs = [-38, 0, 38];
            let cnt = 0, nx = 0, nz = 0, ny = 0, pen = 0;
            for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) {
                const ax = this.px - this.bx * offs[i] + this.ux * 12, ay = this.py - this.by * offs[i] + this.uy * 12, az = this.pz - this.bz * offs[i] + this.uz * 12;
                const bx = o.px - o.bx * offs[j] + o.ux * 12, by = o.py - o.by * offs[j] + o.uy * 12, bz = o.pz - o.bz * offs[j] + o.uz * 12;
                const dx = ax - bx, dy = ay - by, dz = az - bz, d = Math.sqrt(dx * dx + dy * dy + dz * dz);
                if (d < 2 * R && d > 1e-4) { nx += dx / d; ny += dy / d; nz += dz / d; pen = Math.max(pen, 2 * R - d); cnt++; }
            }
            if (!cnt) return 0;
            const l = Math.sqrt(nx * nx + ny * ny + nz * nz) || 1; nx /= l; ny /= l; nz /= l;
            this.px += nx * pen * 0.5; this.py += ny * pen * 0.5; this.pz += nz * pen * 0.5;
            const rvn = (this.vx - o.vx) * nx + (this.vy - o.vy) * ny + (this.vz - o.vz) * nz;
            if (rvn < 0) { const j = -(1 + 0.35) * rvn * 0.5; this.vx += nx * j; this.vy += ny * j; this.vz += nz * j; return -rvn; }
            return 0;
        }
        flags() { return (this.boosting ? 1 : 0) | (this.onGround ? 2 : 0) | (this.handbrake ? 4 : 0) | (this.flipT > 0 ? 8 : 0); }
        getState() {
            return {p: [this.px, this.py, this.pz], v: [this.vx, this.vy, this.vz], q: this.q.slice(), w: [this.wx, this.wy, this.wz],
                    b: this.boost, st: this.steerVis, f: this.flags()};
        }
    }
    root.CarBody = CarBody;
    root.CAR_PARAMS = P;
    if (typeof module !== 'undefined' && module.exports) module.exports = {CarBody, CAR_CONFIGS, getCarStats, CAR_PARAMS: P};
})(typeof window !== 'undefined' ? window : globalThis);
