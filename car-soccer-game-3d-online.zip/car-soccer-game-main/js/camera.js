// Camera System — cámara en tercera persona detrás del coche y cámara que sigue la pelota (tecla C)
function setupCamera() {
    console.log('📷 Camera initialized');
}

// (conservada de la versión original)
function updateCameraView(camera, target) {
    if (!camera || !target) return;
    camera.targetX = target.x;
    camera.targetY = target.y - 15;
    camera.targetZ = target.z + 8;
}

class CameraRig {
    constructor(camera) {
        this.cam = camera; this.mode = 'ball';           // 'ball' | 'car'
        this.dist = 300; this.height = 105;
        this.pos = new THREE.Vector3(0, 300, 800); this.fwd = new THREE.Vector3(0, 0, -1); this.up = new THREE.Vector3(0, 1, 0);
        this.look = new THREE.Vector3(); this._f = new THREE.Vector3(); this._t = new THREE.Vector3(); this._u = new THREE.Vector3(); this._c = {d: 0, nx: 0, ny: 0, nz: 0};
        this.snap = true; this.shake = 0;
    }
    toggle() { this.mode = this.mode === 'ball' ? 'car' : 'ball'; return this.mode; }
    /** car: CarBody (con ejes rx..bz), ball: {px,py,pz} */
    update(dt, car, ball) {
        const U = this._u.set(car.ux, car.uy, car.uz), P = this._t.set(car.px, car.py, car.pz);
        const upT = car.onGround ? U : new THREE.Vector3(0, 1, 0);
        this.up.lerp(upT, snapK(this.snap, 4, dt)).normalize();
        const f = this._f;
        if (this.mode === 'ball') { f.set(ball.px - car.px, ball.py - car.py, ball.pz - car.pz); if (f.length() < 150) f.set(-car.bx, -car.by, -car.bz); }
        else f.set(-car.bx, -car.by, -car.bz);
        f.addScaledVector(this.up, -f.dot(this.up));
        if (f.lengthSq() < 1e-6) f.set(-car.bx, 0, -car.bz);
        f.normalize();
        this.fwd.lerp(f, snapK(this.snap, this.mode === 'ball' ? 7 : 5, dt)).normalize();
        const want = new THREE.Vector3().copy(P).addScaledVector(this.fwd, -this.dist).addScaledVector(this.up, this.height);
        this.pos.lerp(want, snapK(this.snap, 14, dt));
        // mantener la cámara dentro del estadio
        RL.arenaContact(this.pos.x, this.pos.y, this.pos.z, this._c);
        if (this._c.d < 70) { const p = 70 - this._c.d; this.pos.x += this._c.nx * p; this.pos.y += this._c.ny * p; this.pos.z += this._c.nz * p; }
        const tgt = new THREE.Vector3();
        if (this.mode === 'ball') { tgt.set(ball.px, ball.py, ball.pz); tgt.lerp(new THREE.Vector3().copy(P).addScaledVector(this.fwd, 400), 0.15); }
        else tgt.copy(P).addScaledVector(this.fwd, 380).addScaledVector(this.up, 30);
        this.look.lerp(tgt, snapK(this.snap, 16, dt));
        this.cam.position.copy(this.pos);
        if (this.shake > 0) { this.shake = Math.max(0, this.shake - dt * 2.5); this.cam.position.x += (Math.random() - 0.5) * 22 * this.shake; this.cam.position.y += (Math.random() - 0.5) * 22 * this.shake; }
        this.cam.up.copy(this.up); this.cam.lookAt(this.look);
        this.snap = false;
    }
    /** Salto inmediato (tras un saque o al empezar) */
    reset() { this.snap = true; }
}
function snapK(snap, rate, dt) { return snap ? 1 : 1 - Math.exp(-rate * dt); }
