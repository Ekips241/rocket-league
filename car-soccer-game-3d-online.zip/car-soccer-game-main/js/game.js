/**
 * game.js — Orquestador del juego 3D.
 *  - Modo SOLO: partida local contra bots (la autoridad es un RL.Match dentro del navegador).
 *  - Modo ONLINE: el servidor es la autoridad de pelota/marcador/tiempo; cada cliente simula su coche,
 *    predice la pelota con el mismo código de físicas (shared/rlcore.js) y la corrige con los snapshots.
 */
let canvas, renderer, scene, camera, cameraRig, ctx = null;
let gameObjects = {player: null, bots: [], ball: null, match: null, stadium: null, effects: null, ballVis: null};
let gameCamera = {x: 0, y: 0, z: 0, targetX: 0, targetY: 0, targetZ: 0};   // (legado)

const STEP = 1 / 120;
const NEUTRAL = {throttle: 0, steer: 0, pitch: 0, roll: 0, jump: false, boost: false, handbrake: false};
const world = {mode: 'solo', myId: 'me', players: {}, score: [0, 0], time: 300, phase: 'countdown', phaseT: 3, ot: false,
    remote: {}, ball: null, pending: null, acc: 0, last: 0, raf: 0, running: false, lastCount: -1, boardKey: '', fpsT: 0, fpsN: 0, pr: 1, hudT: 0, sendT: 0};
const visuals = {};

// ---- ajustes persistentes
const gameSettings = Object.assign({volume: 0.6, fov: 80, ballCam: true, quality: 'auto', showFps: false, botCount: 3, name: ''},
    (() => { try { return JSON.parse(localStorage.getItem('carsoccer.settings') || '{}'); } catch (e) { return {}; } })());
function saveSettings() { try { localStorage.setItem('carsoccer.settings', JSON.stringify(gameSettings)); } catch (e) {} }
function getPlayerName() { return (gameSettings.name || 'Jugador').slice(0, 16); }
function getPlayerLook() { return Object.assign({}, DEFAULT_LOOK, gameState.look || {}, {type: gameState.selectedCar}); }

// ------------------------------------------------------------------ inicialización
function initGame() {
    canvas = document.getElementById('game-canvas');
    if (typeof THREE === 'undefined') { showToast('No se pudo cargar three.js (¿sin conexión y sin npm install?)', 'warn'); return false; }
    if (!renderer) {
        renderer = new THREE.WebGLRenderer({canvas: canvas, antialias: true, powerPreference: 'high-performance'});
        renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.05;
        window.addEventListener('resize', resizeCanvas);
    }
    if (scene) disposeScene();
    scene = new THREE.Scene(); scene.background = new THREE.Color(0x070b16);
    camera = new THREE.PerspectiveCamera(gameSettings.fov, window.innerWidth / window.innerHeight, 10, 60000);
    cameraRig = new CameraRig(camera); cameraRig.mode = gameSettings.ballCam ? 'ball' : 'car';
    world.pr = gameSettings.quality === 'low' ? 0.65 : gameSettings.quality === 'high' ? Math.min(window.devicePixelRatio || 1, 2) : Math.min(window.devicePixelRatio || 1, 1.25);
    resizeCanvas();
    gameObjects.stadium = createStadium(gameState.selectedStadium, scene, renderer);
    gameObjects.effects = new Effects(scene, camera);
    gameObjects.ballVis = new BallVisual(scene);
    initializeGameObjects();
    return true;
}

function resizeCanvas() {
    if (!renderer) return;
    const w = window.innerWidth, h = window.innerHeight;
    renderer.setPixelRatio(world.pr); renderer.setSize(w, h, false);
    if (camera) { camera.aspect = w / h; camera.fov = gameSettings.fov; camera.updateProjectionMatrix(); }
}

function initializeGameObjects() {
    Object.keys(visuals).forEach(removeVisual); world.remote = {}; gameObjects.bots = [];
    const name = getPlayerName(), look = getPlayerLook();
    world.score = [0, 0]; world.time = 300; world.phase = 'countdown'; world.phaseT = 3; world.ot = false; world.lastCount = -1; world.pending = null;
    if (world.mode === 'solo') {
        const match = new RL.Match(); gameObjects.match = match; world.myId = 'me'; world.players = {};
        const me = match.addPlayer('me', {name: name, look: look}); world.players.me = {id: 'me', name: name, team: me.team, look: look, goals: 0};
        gameObjects.player = new CarBody({id: 'me', team: me.team, type: gameState.selectedCar});
        placeAtSpawn(gameObjects.player, me.team, me.spawn);
        addVisual('me', name, me.team, look, true);
        const n = Math.max(0, Math.min(7, gameSettings.botCount | 0)), pal = ['#ff7a14', '#7a4cff', '#30d0c8', '#e8e8f0', '#ff4d6a', '#ffbe0b', '#00ff88'];
        for (let i = 0; i < n; i++) {
            const id = 'bot' + (i + 1), bl = {c1: pal[i % pal.length], c2: '#101828', wheel: '#222222', finish: 'gloss', type: 'fennec'};
            const c = match.addPlayer(id, {name: 'Bot ' + (i + 1), look: bl});
            const body = new CarBody({id: id, team: c.team, type: 'fennec'}); placeAtSpawn(body, c.team, c.spawn);
            gameObjects.bots.push({id: id, body: body, ai: {stuck: 0, rev: 0, role: (match.order.filter(k => match.cars[k].team === c.team).length) % 2}});
            world.players[id] = {id: id, name: 'Bot ' + (i + 1), team: c.team, look: bl, goals: 0};
            addVisual(id, 'Bot ' + (i + 1), c.team, bl, false);
        }
        match.drainEvents(); gameObjects.ball = match.ball;
    } else {
        gameObjects.match = null; world.myId = Net.id; world.ball = RL.newBall(); gameObjects.ball = world.ball;
        world.players = {}; Net.players.forEach(p => world.players[p.id] = p);
        const me = world.players[world.myId] || {team: Net.team};
        gameObjects.player = new CarBody({id: world.myId, team: me.team, type: gameState.selectedCar});
        const sp = Net.spawn || RL.spawnFor(me.team, 0); gameObjects.player.reset(sp.x, sp.z, sp.yaw);
        addVisual(world.myId, name, me.team, look, true);
        Net.players.forEach(p => { if (p.id !== world.myId) ensureRemote(p); });
    }
    cameraRig.reset();
}
function placeAtSpawn(body, team, idx) { const sp = RL.spawnFor(team, idx); body.reset(sp.x, sp.z, sp.yaw); }

// ------------------------------------------------------------------ visuales de coches
let _shadowTex = null;
function shadowTexture() {
    if (_shadowTex) return _shadowTex;
    const c = document.createElement('canvas'); c.width = c.height = 64; const g = c.getContext('2d');
    const gr = g.createRadialGradient(32, 32, 2, 32, 32, 32); gr.addColorStop(0, 'rgba(0,0,0,0.75)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = gr; g.fillRect(0, 0, 64, 64); return (_shadowTex = new THREE.CanvasTexture(c));
}
function addVisual(id, name, team, look, isLocal) {
    removeVisual(id);
    const model = buildCarModel(look); setCarTeamColor(model, team); scene.add(model);
    let tag = null; if (!isLocal) { tag = makeNameTag(name, team === 0 ? '#2d7bff' : '#ff8a1f'); model.add(tag); }
    const shadow = new THREE.Mesh(new THREE.PlaneGeometry(150, 210), new THREE.MeshBasicMaterial({map: shadowTexture(), transparent: true, depthWrite: false}));
    shadow.rotation.x = -Math.PI / 2; scene.add(shadow);
    visuals[id] = {model: model, tag: tag, shadow: shadow};
}
function removeVisual(id) {
    const v = visuals[id]; if (!v) return;
    scene && scene.remove(v.model); scene && scene.remove(v.shadow); delete visuals[id];
}
function makeRemote(p) {
    const c = {id: p.id, team: p.team, px: 0, py: 18, pz: 0, vx: 0, vy: 0, vz: 0, q: [0, 0, 0, 1], boost: 33, onGround: true, boosting: false, steerVis: 0, spin: 0, flipT: 0,
        wheels: [0, 1, 2, 3].map(() => ({drop: 6})), buf: [], seen: false};
    RL.quatAxes(c.q, c); return c;
}
function ensureRemote(p) {
    if (world.remote[p.id]) return;
    world.remote[p.id] = makeRemote(p); world.players[p.id] = p; addVisual(p.id, p.name, p.team, p.look, false);
}
/** Lista de jugadores cambió (alguien entró, salió o cambió su aspecto) */
function onPlayersChanged(list) {
    if (!world.running || world.mode !== 'online') return;
    const ids = {}; list.forEach(p => { ids[p.id] = true; world.players[p.id] = p; if (p.id !== world.myId) {
        if (!world.remote[p.id]) ensureRemote(p); else if (visuals[p.id]) applyCarLook(visuals[p.id].model, p.look); } });
    Object.keys(world.remote).forEach(id => { if (!ids[id]) { delete world.remote[id]; removeVisual(id); delete world.players[id]; } });
}

// ------------------------------------------------------------------ red: snapshots y eventos
function onSnapshot(m) {
    if (!world.running || world.mode !== 'online') return;
    const now = performance.now();
    world.score = m.score; world.time = m.time; world.phase = m.ph; world.phaseT = m.pt; world.ot = m.ot;
    world.pending = m.ball; gameObjects.stadium.setPads(m.pads);
    Object.keys(m.cars).forEach(id => {
        if (id === world.myId) return;
        let r = world.remote[id]; if (!r) { const p = Net.players.find(x => x.id === id); if (!p) return; ensureRemote(p); r = world.remote[id]; }
        const a = m.cars[id]; r.buf.push({t: now, p: [a[0], a[1], a[2]], v: [a[3], a[4], a[5]], q: a[6], b: a[7], f: a[8], st: a[9]});
        while (r.buf.length > 2 && now - r.buf[0].t > 1000) r.buf.shift();
    });
}
function onServerEvent(e) { if (world.running) handleEvent(e); }

function handleEvent(e) {
    const fx = gameObjects.effects, st = gameObjects.stadium, car = gameObjects.player;
    switch (e.type) {
        case 'kickoff': {
            const sp = e.spawns && e.spawns[world.myId]; if (sp && car) { car.reset(sp.x, sp.z, sp.yaw); cameraRig.reset(); }
            if (world.mode === 'solo') gameObjects.bots.forEach(b => { const s = e.spawns[b.id]; if (s) b.body.reset(s.x, s.z, s.yaw); });
            gameObjects.ballVis.clearTrail(); showBigMessage(''); break;
        }
        case 'go': showBigMessage('¡YA!', '', 'go'); setTimeout(() => showBigMessage(''), 800); playSound('go'); break;
        case 'overtime': showToast('¡PRÓRROGA! Gol de oro', 'warn'); break;
        case 'goal': {
            const nm = e.scorer && world.players[e.scorer] ? world.players[e.scorer].name : '';
            if (e.players) e.players.forEach(p => { if (world.players[p.id]) world.players[p.id].goals = p.goals; });
            else if (e.scorer && world.players[e.scorer]) world.players[e.scorer].goals++;
            showBigMessage('¡GOL!', (e.team === 0 ? 'AZUL' : 'NARANJA') + (nm ? ' · ' + nm : ''), e.team === 0 ? 'blue' : 'orange');
            st.goalFlash(e.team); playSound('goal'); cameraRig.shake = 1;
            const z = e.team === 0 ? RL.C.HALF_L : -RL.C.HALF_L;
            fx.burst(0, 330, z, 160, 1700, e.team === 0 ? 0x4d8bff : 0xffa040, 1.6); fx.ring(0, 330, z, 1400, e.team === 0 ? 0x4d8bff : 0xffa040, 0.9); break;
        }
        case 'end': {
            if (e.players) e.players.forEach(p => { if (world.players[p.id]) world.players[p.id].goals = p.goals; });
            const w = e.winner; showBigMessage(w < 0 ? 'EMPATE' : (w === 0 ? 'AZUL GANA' : 'NARANJA GANA'), e.score[0] + ' - ' + e.score[1] + ' · nueva partida en breve', w === 0 ? 'blue' : w === 1 ? 'orange' : ''); break;
        }
        case 'newmatch': Object.keys(world.players).forEach(k => world.players[k].goals = 0); showBigMessage(''); break;
        case 'pickup': {
            const padBig = e.pad < RL.BIG.length;
            if (world.mode === 'solo') { if (e.id === 'me') { car.boost = e.boost; playSound('pickup'); } else { const b = gameObjects.bots.find(x => x.id === e.id); if (b) b.body.boost = e.boost; } }
            else if (car) { car.boost = Math.min(100, car.boost + (padBig ? 100 : 12)); playSound('pickup'); }
            break;
        }
    }
}

// ------------------------------------------------------------------ bucle
function playGame() {
    if (world.running) return;
    world.running = true; world.last = performance.now(); world.acc = 0; world.raf = requestAnimationFrame(frame);
}
function startGameLoop() { playGame(); }

function frame(now) {
    if (!world.running) return;
    world.raf = requestAnimationFrame(frame);
    const dt = Math.min((now - world.last) / 1000, 0.05); world.last = now;
    const paused = gameState.isPaused && world.mode === 'solo';
    if (!paused) {
        world.acc += dt;
        if (world.mode === 'online') applyPendingBall();
        let steps = 0;
        while (world.acc >= STEP && steps < 8) { update(STEP); world.acc -= STEP; steps++; }
        if (steps === 8) world.acc = 0;
        postUpdate(dt, now);
    }
    render(dt, now);
    updateFps(dt, now);
}

/** Un paso fijo de simulación (1/120 s) */
function update(dt) {
    const car = gameObjects.player, phase = world.mode === 'solo' ? gameObjects.match.phase : world.phase;
    const frozen = phase === 'countdown' || phase === 'ended' || (gameState.isPaused && world.mode === 'online');
    const ctl = frozen ? NEUTRAL : getControls();
    car.step(dt, ctl);
    if (world.mode === 'solo') {
        const match = gameObjects.match;
        gameObjects.bots.forEach(b => { b.body.step(dt, frozen ? NEUTRAL : updateOpponentAI(b, dt)); });
        // colisiones coche-coche (cada coche resuelve su propia parte)
        const all = [car].concat(gameObjects.bots.map(b => b.body));
        for (let i = 0; i < all.length; i++) for (let j = 0; j < all.length; j++) if (i !== j) all[i].collideCar(all[j]);
        match.setCar('me', car.getState()); gameObjects.bots.forEach(b => match.setCar(b.id, b.body.getState()));
        match.step(dt);
        match.drainEvents().forEach(handleEvent);
        world.score = match.score; world.time = match.time; world.phase = match.phase; world.phaseT = match.phaseT; world.ot = match.overtime;
        Object.keys(world.players).forEach(k => { if (match.cars[k]) world.players[k].goals = match.cars[k].goals; });
    } else {
        Object.keys(world.remote).forEach(id => car.collideCar(world.remote[id]));
        if (world.phase === 'playing' || world.phase === 'goal') {
            const b = world.ball; RL.stepBall(b, dt); b.tnow = {};
            const list = [car]; Object.keys(world.remote).forEach(id => list.push(world.remote[id]));
            for (let i = 0; i < list.length; i++) { const c = list[i];
                if (RL.carBallCollide(b, c, !b.tprev[c.id], {x: c.px, y: c.py, z: c.pz}) > 0) b.tnow[c.id] = true; }
            b.tprev = b.tnow;
        }
    }
}

/** Tras los pasos de física: efectos, red, sonidos. */
function postUpdate(dt, now) {
    const car = gameObjects.player, ball = gameObjects.ball;
    if (consumeCameraToggle()) { const m = cameraRig.toggle(); showToast('Cámara: ' + (m === 'ball' ? 'seguir pelota' : 'detrás del coche')); }
    if (ball.hit > 700) { gameObjects.effects.ballHit(ball, ball.hit); gameObjects.ballVis.hit(ball.hit); playSound('hit', ball.hit);
        const d = Math.hypot(ball.px - car.px, ball.pz - car.pz); if (d < 300) cameraRig.shake = Math.max(cameraRig.shake, Math.min(0.6, ball.hit / 5000)); }
    ball.hit = 0;
    if (ball.wallHit > 1200) { gameObjects.effects.burst(ball.px, ball.py, ball.pz, 10, 500, 0x9ad0ff, 0.5); playSound('hit', ball.wallHit * 0.4); }
    ball.wallHit = 0;
    // sonidos del coche local
    if (car.jumped && !world._jp) playSound('jump'); world._jp = car.jumped;
    if (car.flipT > 0.55 && !world._fp) playSound('flip'); world._fp = car.flipT > 0.55;
    if (car.boosting && gameObjects.effects && Math.random() < 0.6) {
        gameObjects.effects.emit(car.px + car.bx * 58, car.py + car.by * 58 - 2, car.pz + car.bz * 58, car.vx * 0.6 + car.bx * 250, car.vy * 0.6 + car.by * 250, car.vz * 0.6 + car.bz * 250, 1, 0.55, 0.15, 0.35); }
    updateEngineSound(Math.hypot(car.vx, car.vy, car.vz), !!getControls().throttle, car.boosting, !gameState.isPaused);
    if (world.mode === 'online') Net.sendState(car.getState(), now);
    // interpolación de coches remotos (100 ms de retraso)
    if (world.mode === 'online') {
        const rt = now - 100;
        Object.keys(world.remote).forEach(id => interpRemote(world.remote[id], rt, dt));
    }
    // cuenta atrás
    if (world.phase === 'countdown') { const n = Math.max(1, Math.ceil(world.phaseT)); if (n !== world.lastCount) { world.lastCount = n; showBigMessage(String(n), '', 'count'); playSound('count'); } }
    else world.lastCount = -1;
}

function interpRemote(r, rt, dt) {
    const b = r.buf; if (!b.length) return;
    let a = null, c = null;
    for (let i = b.length - 1; i >= 0; i--) { if (b[i].t <= rt) { a = b[i]; c = b[i + 1] || null; break; } }
    if (!a) { a = b[0]; c = null; }
    let p, v, q;
    if (c) { const k = (rt - a.t) / Math.max(1, c.t - a.t);
        p = [a.p[0] + (c.p[0] - a.p[0]) * k, a.p[1] + (c.p[1] - a.p[1]) * k, a.p[2] + (c.p[2] - a.p[2]) * k]; v = c.v;
        q = [a.q[0] + (c.q[0] - a.q[0]) * k, a.q[1] + (c.q[1] - a.q[1]) * k, a.q[2] + (c.q[2] - a.q[2]) * k, a.q[3] + (c.q[3] - a.q[3]) * k];
        const dot = a.q[0] * c.q[0] + a.q[1] * c.q[1] + a.q[2] * c.q[2] + a.q[3] * c.q[3];
        if (dot < 0) q = [a.q[0] + (-c.q[0] - a.q[0]) * k, a.q[1] + (-c.q[1] - a.q[1]) * k, a.q[2] + (-c.q[2] - a.q[2]) * k, a.q[3] + (-c.q[3] - a.q[3]) * k];
        const l = Math.hypot(q[0], q[1], q[2], q[3]) || 1; q = [q[0] / l, q[1] / l, q[2] / l, q[3] / l];
    } else { const e = Math.min(0.15, Math.max(0, (rt - a.t) / 1000)); p = [a.p[0] + a.v[0] * e, a.p[1] + a.v[1] * e, a.p[2] + a.v[2] * e]; v = a.v; q = a.q; }
    r.px = p[0]; r.py = p[1]; r.pz = p[2]; r.vx = v[0]; r.vy = v[1]; r.vz = v[2]; r.q = q; RL.quatAxes(q, r);
    r.boost = a.b; r.boosting = (a.f & 1) !== 0; r.onGround = (a.f & 2) !== 0; r.flipT = (a.f & 8) ? 0.3 : 0; r.steerVis += (a.st - r.steerVis) * Math.min(1, dt * 12);
    r.spin += (-(r.vx * r.bx + r.vy * r.by + r.vz * r.bz) / 40) * dt;
}

/** Corrige la pelota predicha localmente con el último estado del servidor. */
function applyPendingBall() {
    const s = world.pending; if (!s) return; world.pending = null;
    const b = world.ball, e = Math.min(0.25, Net.rtt / 2000);
    const px = s[0] + s[3] * e, py = s[1] + s[4] * e, pz = s[2] + s[5] * e;
    const hard = world.phase === 'countdown' || world.phase === 'ended';
    const err = Math.hypot(px - b.px, py - b.py, pz - b.pz);
    if (hard || err > 260) { b.px = px; b.py = py; b.pz = pz; b.vx = s[3]; b.vy = s[4]; b.vz = s[5]; }
    else { const k = 0.3; b.px += (px - b.px) * k; b.py += (py - b.py) * k; b.pz += (pz - b.pz) * k; b.vx += (s[3] - b.vx) * k; b.vy += (s[4] - b.vy) * k; b.vz += (s[5] - b.vz) * k; }
    b.wx = s[6]; b.wy = s[7]; b.wz = s[8];
}

// ------------------------------------------------------------------ IA de los bots
function updateOpponentAI(bot, dt) {
    const c = bot.body, ball = gameObjects.ball, ai = bot.ai, HL = RL.C.HALF_L, atk = c.team === 0 ? 1 : -1;
    const ctl = {throttle: 1, steer: 0, pitch: 0, roll: 0, jump: false, boost: false, handbrake: false};
    const fx = -c.bx, fz = -c.bz, fl = Math.hypot(fx, fz) || 1, hx = fx / fl, hz = fz / fl, rx = -hz, rz = hx;
    // objetivo: atacante va a la pelota por detrás; defensor se coloca entre la pelota y su portería
    let tx = ball.px, tz = ball.pz;
    const gx = 0, gz = atk * HL, dx = gx - ball.px, dz = gz - ball.pz, dl = Math.hypot(dx, dz) || 1;
    const onSide = (c.pz - ball.pz) * atk < -120;
    if (ai.role === 1 && (ball.pz * atk) > 0) { tx = ball.px * 0.5; tz = -atk * (HL - 1500) * 0.7 + ball.pz * 0.3; }
    else if (!onSide) { tx = ball.px - dx / dl * 520; tz = ball.pz - dz / dl * 520; }
    else { tx = ball.px - dx / dl * 60; tz = ball.pz - dz / dl * 60; }
    const ex = tx - c.px, ez = tz - c.pz, dist = Math.hypot(ex, ez) || 1;
    const ang = Math.atan2((ex * rx + ez * rz), (ex * hx + ez * hz));
    const speed = Math.hypot(c.vx, c.vz);
    if (ai.rev > 0) { ai.rev -= dt; ctl.throttle = -1; ctl.steer = -Math.sign(ai.dir || 1); return ctl; }
    ai.stuck = (speed < 90 && world.phase === 'playing') ? ai.stuck + dt : 0;
    if (ai.stuck > 1.1) { ai.rev = 0.8; ai.dir = Math.random() < 0.5 ? 1 : -1; ai.stuck = 0; }
    ctl.steer = Math.max(-1, Math.min(1, ang * 2.4));
    if (Math.abs(ang) > 1.2 && dist < 700) { ctl.throttle = 0.4; ctl.handbrake = Math.abs(ang) > 1.9 && speed > 600; }
    if (Math.abs(ang) < 0.22 && dist > 900 && c.boost > 12 && speed < 2150) ctl.boost = true;
    // saltos / voltereta al llegar a la pelota
    const bd = Math.hypot(ball.px - c.px, ball.pz - c.pz);
    if (c.onGround && bd < 330 && ball.py > 170 && Math.abs(ang) < 0.5 && !ai.air) { ctl.jump = true; ai.air = 0.6; }
    if (ai.air > 0) { ai.air -= dt; ctl.jump = ai.air > 0.4 || (ai.air < 0.3 && ai.air > 0.2); if (ai.air < 0.3 && bd < 380) { ctl.pitch = 1; ctl.steer = 0; } }
    else if (!c.onGround) { ctl.throttle = 0; ctl.pitch = c.uy < 0.3 ? 0 : 0; ctl.roll = c.uy < 0.2 ? 1 : 0; ctl.boost = false; }
    if (c.onGround && bd < 260 && Math.abs(ang) < 0.35 && ball.py < 170 && !ai.air && Math.random() < dt * 1.2) ai.air = 0.45;
    return ctl;
}

// ------------------------------------------------------------------ renderizado y HUD
function updateCamera() { cameraRig.update(1 / 60, gameObjects.player, gameObjects.ball); }

function render(dt, now) {
    if (!renderer) return;
    const t = now / 1000, car = gameObjects.player, fx = gameObjects.effects;
    // coche local, bots y remotos
    syncVisual(world.myId, car, t);
    gameObjects.bots.forEach(b => syncVisual(b.id, b.body, t));
    Object.keys(world.remote).forEach(id => syncVisual(id, world.remote[id], t));
    gameObjects.ballVis.update(gameObjects.ball, dt);
    fx.update(dt); gameObjects.stadium.update(dt);
    if (world.mode === 'solo' && (world.hudT += dt) > 0.2) gameObjects.stadium.setPads(gameObjects.match.pads.map(p => p.t > 0 ? 1 : 0).join(''));
    cameraRig.dist = 300; cameraRig.update(dt, car, gameObjects.ball);
    updateHUD(dt);
    renderer.render(scene, camera);
}
function syncVisual(id, car, t) {
    const v = visuals[id]; if (!v) return;
    v.model.position.set(car.px, car.py, car.pz); v.model.quaternion.set(car.q[0], car.q[1], car.q[2], car.q[3]);
    updateCarModel(v.model, car, t);
    const h = Math.max(0, car.py), flat = car.uy > 0.5 && Math.abs(car.px) < 4300 && Math.abs(car.pz) < 6000;
    v.shadow.visible = flat && h < 700; v.shadow.position.set(car.px, 1.2, car.pz);
    v.shadow.rotation.order = 'YXZ'; v.shadow.rotation.set(-Math.PI / 2, Math.atan2(car.bx, car.bz), 0);
    v.shadow.material.opacity = Math.max(0.1, 0.8 - h / 700);
}

function updateHUD(dt) {
    const car = gameObjects.player;
    gameState.score.blue = world.score[0]; gameState.score.orange = world.score[1]; gameState.gameTime = world.time;
    updateScoreDisplay(); updateTimerDisplay(); updateBoostDisplay(car.boost);
    const key = world.score[0] + '-' + world.score[1] + '-' + Math.ceil(world.time) + world.phase + world.ot;
    if (key !== world.boardKey) { world.boardKey = key; const m = Math.floor(world.time / 60), s = Math.floor(world.time % 60);
        gameObjects.stadium.setScore(world.score, m + ':' + String(s).padStart(2, '0'), world.phase, world.ot); }
    const ni = document.getElementById('net-info');
    if (ni) { ni.textContent = world.mode === 'online' ? ('SALA ' + (Net.room || '') + ' · ' + Object.keys(world.players).length + '/' + RL.C.MAX_PLAYERS + ' jugadores · ' + Math.round(Net.rtt) + ' ms') : 'PARTIDA LOCAL · ' + Object.keys(world.players).length + ' jugadores'; }
    const sb = document.getElementById('scoreboard-overlay');
    if (sb) { const show = isTabHeld(); sb.classList.toggle('hidden', !show); if (show) renderPlayerList(document.getElementById('scoreboard-list'), Object.keys(world.players).map(k => world.players[k]), world.myId); }
}
function updateFps(dt, now) {
    world.fpsN++; world.fpsT += dt;
    if (world.fpsT >= 1) {
        const fps = world.fpsN / world.fpsT; world.fpsN = 0; world.fpsT = 0;
        const el = document.getElementById('fps-counter'); if (el) { el.classList.toggle('hidden', !gameSettings.showFps); el.textContent = Math.round(fps) + ' FPS'; }
        if (gameSettings.quality === 'auto') {            // resolución dinámica para mantener ~60 FPS
            if (fps < 50 && world.pr > 0.6) { world.pr = Math.max(0.6, world.pr - 0.1); resizeCanvas(); }
            else if (fps > 59 && world.pr < Math.min(window.devicePixelRatio || 1, 1.25)) { world.pr = Math.min(Math.min(window.devicePixelRatio || 1, 1.25), world.pr + 0.05); resizeCanvas(); }
        }
    }
}

// ------------------------------------------------------------------ utilidades
function resetGameObjects() { initializeGameObjects(); }
function disposeScene() {
    scene.traverse(o => { if (o.geometry) o.geometry.dispose(); if (o.material) { (Array.isArray(o.material) ? o.material : [o.material]).forEach(m => { if (m.map) m.map.dispose(); m.dispose(); }); } });
    Object.keys(visuals).forEach(k => delete visuals[k]);
}
function cleanupGame() {
    world.running = false; cancelAnimationFrame(world.raf);
    updateEngineSound(0, false, false, false);
    if (world.mode === 'online') Net.leave();
    if (scene) { disposeScene(); scene = null; }
    gameObjects = {player: null, bots: [], ball: null, match: null, stadium: null, effects: null, ballVis: null};
    showBigMessage('');
}
