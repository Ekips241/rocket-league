/**
 * network.js — Cliente WebSocket de las salas online.
 * Mensajes: create/join/s(estado)/look/ping/leave  →  hello/joined/players/snap/ev/left/error/pong
 */
const Net = {
    ws: null, connected: false, id: null, room: null, team: 0, spawn: null, players: [], rtt: 80, handlers: {},
    _lastSend: 0, _pingTimer: null,
    on(type, fn) { this.handlers[type] = fn; },
    url() { return (location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/ws'; },
    connect() {
        return new Promise((resolve, reject) => {
            if (location.protocol === 'file:') return reject(new Error('Abre el juego desde el servidor (npm start → http://localhost:3000); el modo online no funciona con file://'));
            if (this.connected) return resolve();
            let ws; try { ws = new WebSocket(this.url()); } catch (e) { return reject(e); }
            this.ws = ws; let opened = false;
            ws.onopen = () => { opened = true; this.connected = true; this._startPing(); resolve(); };
            ws.onerror = () => { if (!opened) reject(new Error('No se pudo conectar con el servidor. ¿Está ejecutándose "npm start"?')); };
            ws.onclose = () => { const was = this.connected; this.connected = false; clearInterval(this._pingTimer); this.room = null; if (was && this.handlers.close) this.handlers.close(); };
            ws.onmessage = (e) => {
                let m; try { m = JSON.parse(e.data); } catch (x) { return; }
                if (m.t === 'hello') this.id = m.id;
                else if (m.t === 'joined') { this.room = m.room; this.team = m.team; this.spawn = m.spawn; this.players = m.players; }
                else if (m.t === 'players' || m.t === 'left') this.players = m.players;
                else if (m.t === 'pong') { const r = performance.now() - m.ts; this.rtt = this.rtt * 0.7 + r * 0.3; }
                const h = this.handlers[m.t]; if (h) h(m);
            };
        });
    },
    send(o) { if (this.ws && this.ws.readyState === 1) this.ws.send(JSON.stringify(o)); },
    create(name, look) { this.send({t: 'create', name, look}); },
    join(code, name, look) { this.send({t: 'join', code, name, look}); },
    sendLook(name, look) { this.send({t: 'look', name, look}); },
    /** Envía el estado del coche local (máx. ~30 veces/s) */
    sendState(st, now) {
        if (now - this._lastSend < 33) return; this._lastSend = now;
        this.send({t: 's', p: st.p.map(round1), v: st.v.map(round1), q: st.q.map(n => Math.round(n * 1e4) / 1e4), w: st.w.map(n => Math.round(n * 100) / 100), b: Math.round(st.b), st: Math.round(st.st * 100) / 100, f: st.f});
    },
    leave() { try { this.send({t: 'leave'}); if (this.ws) this.ws.close(); } catch (e) {} this.connected = false; this.room = null; this.players = []; clearInterval(this._pingTimer); },
    _startPing() { clearInterval(this._pingTimer); this._pingTimer = setInterval(() => this.send({t: 'ping', ts: performance.now()}), 2000); }
};
function round1(n) { return Math.round(n * 10) / 10; }
