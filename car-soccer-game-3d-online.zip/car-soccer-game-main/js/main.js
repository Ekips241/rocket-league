// Global Game State
let gameState = {
    isPlaying: false,
    isPaused: false,
    currentMenu: 'features',
    selectedCar: 'fennec',
    selectedStadium: 'neon-arena',
    carColor: '#00d4ff',
    trailEffect: 'neon',
    look: null,
    score: {
        blue: 0,
        orange: 0
    },
    gameTime: 300
};

const LOOK_KEY = 'carsoccer.look';
const SWATCHES = {
    c1: ['#00d4ff', '#ff006e', '#00ff66', '#ffbe0b', '#ff3b30', '#7a4cff', '#f2f2f2', '#1b1b1f'],
    c2: ['#101828', '#ffffff', '#ffbe0b', '#00d4ff', '#ff006e', '#00ff66', '#7a4cff', '#444a55'],
    wheel: ['#222222', '#c0c4cc', '#ffbe0b', '#ff006e', '#00d4ff', '#00ff66', '#ffffff', '#7a4cff']
};
let preview = null;   // vista previa 3D de la personalización

document.addEventListener('DOMContentLoaded', () => {
    console.log('🚀 3D Car Soccer Game Initialized');
    initializeGame();
    setupEventListeners();
});

function initializeGame() {
    const heroCanvas = document.getElementById('hero-canvas');
    if (heroCanvas) {
        setupHeroAnimation(heroCanvas);
    }
    initializeAudio();
    loadLook();
    initCustomizationUI();
    initSettingsUI();
    const nm = document.getElementById('player-name');
    if (nm) { nm.value = gameSettings.name || ''; nm.addEventListener('input', () => { gameSettings.name = nm.value.trim().slice(0, 16); saveSettings(); }); }
    setupNetwork();
}

function setupEventListeners() {
    document.querySelectorAll('.car-card').forEach(card => {
        card.addEventListener('click', () => {
            selectCar(card.dataset.car);
        });
    });

    document.querySelectorAll('.stadium-card').forEach(card => {
        card.addEventListener('click', () => {
            selectStadium(card.dataset.stadium);
        });
    });

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            if (gameState.isPaused) {
                resumeGame();
            }
        }
        if (e.key === 'Enter' && gameState.currentMenu === 'join' && document.getElementById('main-menu').classList.contains('active')) joinRoom();
    });
    const code = document.getElementById('join-code');
    if (code) code.addEventListener('input', () => { code.value = code.value.toUpperCase().replace(/[^A-Z0-9]/g, ''); });
}

// ------------------------------------------------------------------ partida
/** mode: 'solo' (por defecto, contra bots) | 'online' */
function startGame(mode) {
    mode = mode === 'online' ? 'online' : 'solo';
    console.log('🎮 Starting game:', mode, 'car:', gameState.selectedCar);
    world.mode = mode;
    if (mode === 'solo' && Net.connected) Net.leave();
    document.getElementById('hero-screen').classList.remove('active');
    document.getElementById('main-menu').classList.remove('active');
    stopPreview();
    document.getElementById('game-canvas').classList.add('active');
    document.getElementById('hud').classList.remove('hidden');
    gameState.isPlaying = true;
    gameState.isPaused = false;
    if (!initGame()) { returnToMenu(); return; }
    playGame();
}

function showMenu(section) {
    document.getElementById('main-menu').classList.add('active');
    switchMenuSection(section);
}

function switchMenuSection(section) {
    document.querySelectorAll('.menu-section').forEach(sec => {
        sec.classList.remove('active');
    });
    const targetSection = document.getElementById(section + '-menu');
    if (targetSection) {
        targetSection.classList.remove('hidden');
        targetSection.classList.add('active');
    }
    gameState.currentMenu = section;
    if (section === 'customization') startPreview(); else stopPreview();
    if (section === 'join') { const e = document.getElementById('join-error'); if (e) e.textContent = ''; setTimeout(() => { const c = document.getElementById('join-code'); c && c.focus(); }, 50); }
    if (section === 'settings') refreshSettingsUI();
}

function closeMenu() {
    document.getElementById('main-menu').classList.remove('active');
    stopPreview();
}

function selectCar(carId) {
    gameState.selectedCar = carId;
    document.querySelectorAll('.car-card').forEach(card => {
        card.classList.remove('active');
    });
    const el = document.querySelector(`[data-car="${carId}"]`); if (el) el.classList.add('active');
    playSound('select');
}

function selectStadium(stadiumId) {
    gameState.selectedStadium = stadiumId;
    document.querySelectorAll('.stadium-card').forEach(card => {
        card.classList.remove('active');
    });
    const el = document.querySelector(`[data-stadium="${stadiumId}"]`); if (el) el.classList.add('active');
    const sel = document.getElementById('set-stadium'); if (sel) sel.value = stadiumId;
    playSound('select');
}

function setCarColor(color) {
    gameState.carColor = color;
    gameState.look.c1 = color;
    refreshLookUI(); updatePreviewLook();
    playSound('select');
}

function setTrailEffect(effect) {
    gameState.trailEffect = effect;
    playSound('select');
}

function pauseGame() {
    if (!gameState.isPlaying) return;
    gameState.isPaused = true;
    const note = document.getElementById('pause-note'); if (note) note.textContent = world.mode === 'online' ? 'En el modo online la partida continúa mientras estás en pausa.' : '';
    document.getElementById('pause-menu').classList.add('active');
    playSound('pause');
}

function resumeGame() {
    if (!gameState.isPlaying) return;
    gameState.isPaused = false;
    document.getElementById('pause-menu').classList.remove('active');
    document.getElementById('main-menu').classList.remove('active');
    playSound('resume');
}

function returnToMenu() {
    gameState.isPlaying = false;
    gameState.isPaused = false;
    document.getElementById('game-canvas').classList.remove('active');
    document.getElementById('hud').classList.add('hidden');
    document.getElementById('pause-menu').classList.remove('active');
    document.getElementById('main-menu').classList.remove('active');
    document.getElementById('hero-screen').classList.add('active');
    cleanupGame();
}

function toggleSettings() {
    playSound('select');
    showMenu('settings');
}

// ------------------------------------------------------------------ online
function setupNetwork() {
    Net.on('joined', m => {
        const el = document.getElementById('room-code'); if (el) el.textContent = m.room;
        refreshLobby(); showMenu('lobby');
        showToast(m.players.length > 1 ? 'Te has unido a la sala ' + m.room : 'Sala ' + m.room + ' creada', 'ok');
    });
    Net.on('error', m => {
        const id = gameState.currentMenu === 'join' ? 'join-error' : 'lobby-error'; const e = document.getElementById(id); if (e) e.textContent = m.msg;
        showToast(m.msg, 'warn'); const b = document.getElementById('join-btn'); if (b) b.disabled = false;
    });
    Net.on('players', m => {
        refreshLobby(); onPlayersChanged(m.players);
        if (m.joined && m.name) showToast(m.name + ' se ha unido a la partida', 'ok');
    });
    Net.on('left', m => { refreshLobby(); onPlayersChanged(m.players); showToast(m.name + ' se ha desconectado', 'warn'); });
    Net.on('snap', onSnapshot);
    Net.on('ev', m => onServerEvent(m.e));
    Net.on('close', () => {
        showToast('Conexión con el servidor perdida', 'warn');
        if (gameState.isPlaying && world.mode === 'online') returnToMenu();
        else if (gameState.currentMenu === 'lobby') showMenu('join');
    });
}
async function connectAndRun(fn, errId) {
    const err = document.getElementById(errId); if (err) err.textContent = '';
    try { await Net.connect(); fn(); }
    catch (e) { if (err) err.textContent = e.message; showToast(e.message, 'warn'); const b = document.getElementById('join-btn'); if (b) b.disabled = false; }
}
function openCreateRoom() { createRoom(); }
function createRoom() {
    showMenu('lobby'); document.getElementById('room-code').textContent = '······'; 
    connectAndRun(() => Net.create(getPlayerName(), getPlayerLook()), 'lobby-error');
}
function joinRoom() {
    const code = (document.getElementById('join-code').value || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
    const err = document.getElementById('join-error');
    if (code.length !== 6) { err.textContent = 'El código tiene 6 caracteres.'; return; }
    document.getElementById('join-btn').disabled = true;
    connectAndRun(() => { Net.join(code, getPlayerName(), getPlayerLook()); setTimeout(() => { document.getElementById('join-btn').disabled = false; }, 800); }, 'join-error');
}
function leaveRoom() { Net.leave(); showMenu('features'); closeMenu(); }
function enterOnlineGame() { if (!Net.room) return; startGame('online'); }
function refreshLobby() {
    const list = document.getElementById('lobby-players'); if (!list) return;
    renderPlayerList(list, Net.players, Net.id);
    const c = document.getElementById('lobby-count'); if (c) c.textContent = Net.players.length + '/8';
}

// ------------------------------------------------------------------ personalización
function loadLook() {
    let saved = {}; try { saved = JSON.parse(localStorage.getItem(LOOK_KEY) || '{}'); } catch (e) {}
    gameState.look = Object.assign({}, DEFAULT_LOOK, saved);
    gameState.carColor = gameState.look.c1;
}
function saveLook() {
    try { localStorage.setItem(LOOK_KEY, JSON.stringify(gameState.look)); } catch (e) {}
    const el = document.getElementById('look-saved'); if (el) el.textContent = '✔ Personalización guardada';
    if (Net.room) Net.sendLook(getPlayerName(), getPlayerLook());
    playSound('select');
}
function resetLook() { gameState.look = Object.assign({}, DEFAULT_LOOK); gameState.carColor = gameState.look.c1; refreshLookUI(); updatePreviewLook(); }
function initCustomizationUI() {
    ['c1', 'c2', 'wheel'].forEach(key => {
        const box = document.getElementById('swatches-' + key), inp = document.getElementById('look-' + key);
        SWATCHES[key].forEach(col => { const d = document.createElement('div'); d.className = 'color-option'; d.style.background = col; d.title = col;
            d.addEventListener('click', () => { gameState.look[key] = col; if (key === 'c1') gameState.carColor = col; refreshLookUI(); updatePreviewLook(); playSound('select'); }); box.appendChild(d); });
        inp.addEventListener('input', () => { gameState.look[key] = inp.value; if (key === 'c1') gameState.carColor = inp.value; updatePreviewLook(); markUnsaved(); });
    });
    document.getElementById('look-finish').addEventListener('change', e => { gameState.look.finish = e.target.value; updatePreviewLook(); markUnsaved(); });
    refreshLookUI();
}
function markUnsaved() { const el = document.getElementById('look-saved'); if (el) el.textContent = 'Cambios sin guardar'; }
function refreshLookUI() {
    const L = gameState.look;
    ['c1', 'c2', 'wheel'].forEach(k => { const i = document.getElementById('look-' + k); if (i) i.value = L[k]; });
    const f = document.getElementById('look-finish'); if (f) f.value = L.finish;
    markUnsaved();
}
function startPreview() {
    const cv = document.getElementById('preview-canvas'); if (!cv || typeof THREE === 'undefined') return;
    if (!preview) {
        const r = new THREE.WebGLRenderer({canvas: cv, antialias: true, alpha: true}); r.setSize(cv.width, cv.height, false);
        const sc = new THREE.Scene(); sc.add(new THREE.HemisphereLight(0xdde8ff, 0x20243a, 1.2)); const dl = new THREE.DirectionalLight(0xffffff, 1.6); dl.position.set(200, 300, 150); sc.add(dl);
        const cam = new THREE.PerspectiveCamera(35, cv.width / cv.height, 1, 2000); cam.position.set(150, 85, 190); cam.lookAt(0, 8, 0);
        const model = buildCarModel(gameState.look); model.position.y = 18; sc.add(model);
        try { const env = new THREE.Scene(); const sg = new THREE.SphereGeometry(100, 16, 8), cols = []; const p = sg.attributes.position;
            for (let i = 0; i < p.count; i++) { const y = p.getY(i) / 100; const c = new THREE.Color(y > 0 ? 0xaac4ff : 0x222a3a).multiplyScalar(0.5 + Math.abs(y) * 0.8); cols.push(c.r, c.g, c.b); }
            sg.setAttribute('color', new THREE.Float32BufferAttribute(cols, 3)); env.add(new THREE.Mesh(sg, new THREE.MeshBasicMaterial({vertexColors: true, side: THREE.BackSide})));
            const pm = new THREE.PMREMGenerator(r); sc.environment = pm.fromScene(env, 0.04).texture; pm.dispose(); } catch (e) {}
        preview = {r, sc, cam, model, run: false, t: 0};
    }
    updatePreviewLook(); preview.run = true;
    const loop = () => { if (!preview || !preview.run) return; preview.t += 0.012; preview.model.rotation.y = preview.t;
        updateCarModel(preview.model, {steerVis: Math.sin(preview.t * 2) * 0.5, spin: preview.t * 6, wheels: null, boosting: false}, preview.t);
        preview.r.render(preview.sc, preview.cam); requestAnimationFrame(loop); };
    loop();
}
function stopPreview() { if (preview) preview.run = false; }
function updatePreviewLook() { if (preview) applyCarLook(preview.model, gameState.look); }

// ------------------------------------------------------------------ ajustes
function initSettingsUI() {
    const bind = (id, key, evt, parse) => { const el = document.getElementById(id); if (!el) return; el.addEventListener(evt, () => { gameSettings[key] = parse(el); saveSettings(); applySettings(); }); };
    bind('set-volume', 'volume', 'input', e => parseFloat(e.value));
    bind('set-fov', 'fov', 'input', e => parseInt(e.value, 10));
    bind('set-ballcam', 'ballCam', 'change', e => e.checked);
    bind('set-quality', 'quality', 'change', e => e.value);
    bind('set-bots', 'botCount', 'change', e => parseInt(e.value, 10));
    bind('set-fps', 'showFps', 'change', e => e.checked);
    refreshSettingsUI(); applySettings();
}
function refreshSettingsUI() {
    const set = (id, v, prop) => { const el = document.getElementById(id); if (el) el[prop || 'value'] = v; };
    set('set-volume', gameSettings.volume); set('set-fov', gameSettings.fov); set('set-ballcam', gameSettings.ballCam, 'checked');
    set('set-quality', gameSettings.quality); set('set-bots', String(gameSettings.botCount)); set('set-fps', gameSettings.showFps, 'checked'); set('set-stadium', gameState.selectedStadium);
    const fv = document.getElementById('set-fov-val'); if (fv) fv.textContent = gameSettings.fov + '°';
}
function applySettings() {
    setMasterVolume(gameSettings.volume);
    const fv = document.getElementById('set-fov-val'); if (fv) fv.textContent = gameSettings.fov + '°';
    if (gameState.isPlaying && camera) { camera.fov = gameSettings.fov; camera.updateProjectionMatrix(); }
}

// ------------------------------------------------------------------ animación del menú (original)
function setupHeroAnimation(canvas) {
    const ctx = canvas.getContext('2d');
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;

    window.addEventListener('resize', () => {
        canvas.width = canvas.offsetWidth;
        canvas.height = canvas.offsetHeight;
    });

    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.strokeStyle = 'rgba(0, 212, 255, 0.1)';
        ctx.lineWidth = 1;

        const gridSize = 50;
        for (let i = 0; i < canvas.width; i += gridSize) {
            ctx.beginPath();
            ctx.moveTo(i, 0);
            ctx.lineTo(i, canvas.height);
            ctx.stroke();
        }
        for (let i = 0; i < canvas.height; i += gridSize) {
            ctx.beginPath();
            ctx.moveTo(0, i);
            ctx.lineTo(canvas.width, i);
            ctx.stroke();
        }

        ctx.fillStyle = 'rgba(0, 212, 255, 0.3)';
        for (let i = 0; i < 20; i++) {
            const x = (Math.sin(Date.now() / 1000 + i) * canvas.width) / 2 + canvas.width / 2;
            const y = (Math.cos(Date.now() / 1500 + i) * canvas.height) / 2 + canvas.height / 2;
            ctx.beginPath();
            ctx.arc(x, y, 2, 0, Math.PI * 2);
            ctx.fill();
        }

        requestAnimationFrame(animate);
    }

    animate();
}

function updateBoostDisplay(boostPercent) {
    const boostFill = document.getElementById('boost-fill');
    const boostText = document.getElementById('boost-text');
    if (boostFill) boostFill.style.width = boostPercent + '%';
    if (boostText) boostText.textContent = `TURBO: ${Math.round(boostPercent)}%`;
}

function updateScoreDisplay() {
    const blueScore = document.getElementById('blue-score');
    const orangeScore = document.getElementById('orange-score');
    if (blueScore) blueScore.textContent = gameState.score.blue;
    if (orangeScore) orangeScore.textContent = gameState.score.orange;
}

function updateTimerDisplay() {
    const timer = document.getElementById('timer');
    if (!timer) return;
    const minutes = Math.floor(gameState.gameTime / 60);
    const seconds = Math.floor(gameState.gameTime % 60);
    timer.textContent = world.ot ? 'PRÓRROGA' : `${minutes}:${seconds.toString().padStart(2, '0')}`;
}

console.log('%c🚗 3D Car Soccer', 'color: #00d4ff; font-size: 20px; font-weight: bold;');
console.log('%cVersion 2.0.0', 'color: #ff006e; font-size: 12px;');
