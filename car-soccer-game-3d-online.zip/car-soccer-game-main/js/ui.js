// UI Management
function initializeUI() {
    console.log('🎨 UI initialized');
}

function updateUI() {
    // UI updates handled in main.js / game.js
}

const TEAM_NAMES = ['AZUL', 'NARANJA'];

/** Aviso temporal en pantalla (jugador conectado/desconectado, errores...) */
function showToast(msg, kind) {
    const box = document.getElementById('toasts'); if (!box) return;
    const t = document.createElement('div'); t.className = 'toast ' + (kind || ''); t.textContent = msg; box.appendChild(t);
    setTimeout(() => t.classList.add('out'), 3200); setTimeout(() => t.remove(), 3800);
}

/** Texto grande central (cuenta atrás, GOL, FIN...). Pasa '' para ocultarlo. */
function showBigMessage(text, sub, cls) {
    const el = document.getElementById('big-message'); if (!el) return;
    if (!text) { el.classList.add('hidden'); return; }
    el.className = 'big-message ' + (cls || ''); el.innerHTML = '<div class="bm-main"></div><div class="bm-sub"></div>';
    el.firstChild.textContent = text; el.lastChild.textContent = sub || '';
}

/** Rellena una lista de jugadores (sala / tabla de clasificación). players: [{id,name,team,goals,look}] */
function renderPlayerList(container, players, myId) {
    if (!container) return;
    container.innerHTML = '';
    players.forEach(p => {
        const row = document.createElement('div'); row.className = 'player-row team' + p.team + (p.id === myId ? ' me' : '');
        const dot = document.createElement('span'); dot.className = 'pdot'; dot.style.background = (p.look && p.look.c1) || '#888';
        const nm = document.createElement('span'); nm.className = 'pname'; nm.textContent = p.name + (p.id === myId ? ' (tú)' : '');
        const tm = document.createElement('span'); tm.className = 'pteam'; tm.textContent = TEAM_NAMES[p.team];
        const gl = document.createElement('span'); gl.className = 'pgoals'; gl.textContent = '⚽ ' + (p.goals || 0);
        row.append(dot, nm, tm, gl); container.appendChild(row);
    });
}

function copyRoomCode(code) {
    const done = () => showToast('Código ' + code + ' copiado', 'ok');
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(code).then(done, () => fallbackCopy(code, done));
    else fallbackCopy(code, done);
}
function fallbackCopy(text, cb) {
    const ta = document.createElement('textarea'); ta.value = text; document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); cb(); } catch (e) { showToast('Copia el código manualmente: ' + text); }
    ta.remove();
}
