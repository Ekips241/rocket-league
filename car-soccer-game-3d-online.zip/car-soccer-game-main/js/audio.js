// Audio System (API original conservada: initializeAudio / playSound / playBeep) + motor y turbo
let _audioCtx = null, _master = null, _engine = null, _boostNoise = null;
const audioSettings = {volume: 0.6};

function getAudioContext() {
    try {
        if (!_audioCtx) {
            _audioCtx = new (window.AudioContext || window.webkitAudioContext)();
            _master = _audioCtx.createGain(); _master.gain.value = audioSettings.volume; _master.connect(_audioCtx.destination);
        }
        if (_audioCtx.state === 'suspended') _audioCtx.resume();
    } catch (e) { return null; }
    return _audioCtx;
}

function initializeAudio() {
    console.log('🔊 Audio system initialized');
    ['pointerdown', 'keydown'].forEach(ev => document.addEventListener(ev, () => getAudioContext(), {once: true}));
}

function setMasterVolume(v) {
    audioSettings.volume = v;
    if (_master) _master.gain.value = v;
}

function playSound(soundType, strength) {
    const audioContext = getAudioContext();
    if (!audioContext) return;
    switch (soundType) {
        case 'select': playBeep(audioContext, 800, 0.1); break;
        case 'jump': playBeep(audioContext, 600, 0.15); break;
        case 'flip': playBeep(audioContext, 900, 0.12); playBeep(audioContext, 450, 0.2); break;
        case 'boost': playBeep(audioContext, 1000, 0.1); break;
        case 'collision': playBeep(audioContext, 400, 0.1); break;
        case 'goal': [523, 659, 784, 1046].forEach((f, i) => setTimeout(() => playBeep(audioContext, f, 0.35), i * 120)); break;
        case 'pause': playBeep(audioContext, 500, 0.1); break;
        case 'resume': playBeep(audioContext, 700, 0.1); break;
        case 'pickup': playBeep(audioContext, 1300, 0.07); break;
        case 'count': playBeep(audioContext, 660, 0.18); break;
        case 'go': playBeep(audioContext, 990, 0.4); break;
        case 'hit': playBeep(audioContext, 140 + 100 * (1 - Math.min(1, (strength || 0) / 3500)), 0.18 + 0.1 * Math.min(1, (strength || 0) / 3500), 'triangle', 0.1 + 0.25 * Math.min(1, (strength || 0) / 3500)); break;
    }
}

function playBeep(audioContext, frequency, duration, type, vol) {
    try {
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        oscillator.connect(gainNode);
        gainNode.connect(_master || audioContext.destination);
        oscillator.frequency.value = frequency;
        oscillator.type = type || 'sine';
        gainNode.gain.setValueAtTime(vol || 0.1, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + duration);
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + duration);
    } catch (e) {
        console.log('Beep failed:', e);
    }
}

/** Sonido continuo del motor (tono según velocidad) y del turbo (ruido). Se llama cada fotograma. */
function updateEngineSound(speed, throttle, boosting, on) {
    const ctx = getAudioContext(); if (!ctx) return;
    if (!_engine) {
        const o = ctx.createOscillator(), g = ctx.createGain(), f = ctx.createBiquadFilter();
        o.type = 'sawtooth'; f.type = 'lowpass'; f.frequency.value = 700; g.gain.value = 0; o.connect(f); f.connect(g); g.connect(_master); o.start();
        const len = ctx.sampleRate, buf = ctx.createBuffer(1, len, ctx.sampleRate), d = buf.getChannelData(0); for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
        const n = ctx.createBufferSource(); n.buffer = buf; n.loop = true; const ng = ctx.createGain(); ng.gain.value = 0; const nf = ctx.createBiquadFilter(); nf.type = 'bandpass'; nf.frequency.value = 900;
        n.connect(nf); nf.connect(ng); ng.connect(_master); n.start();
        _engine = {o, g}; _boostNoise = {g: ng};
    }
    const t = ctx.currentTime;
    _engine.o.frequency.setTargetAtTime(55 + Math.min(1, speed / 2300) * 150 + (throttle ? 18 : 0), t, 0.08);
    _engine.g.gain.setTargetAtTime(on ? 0.035 + (throttle ? 0.02 : 0) : 0, t, 0.1);
    _boostNoise.g.gain.setTargetAtTime(on && boosting ? 0.05 : 0, t, 0.05);
}
