global.RL = require('../shared/rlcore.js');
const {CarBody} = require('../js/cars.js');
const dt = 1/120;
function run(car, secs, inp, log) { for (let i=0;i<secs/dt;i++){ car.step(dt, typeof inp==='function'?inp(i*dt):inp); if(!isFinite(car.px+car.py+car.pz)) throw new Error('NaN'); } if(log) console.log(log, car.px.toFixed(0), car.py.toFixed(1), car.pz.toFixed(0), 'v', Math.hypot(car.vx,car.vy,car.vz).toFixed(0), 'ground', car.nGround); }
const none={throttle:0,steer:0,pitch:0,roll:0,jump:false,boost:false,handbrake:false};
let c = new CarBody({}); c.reset(0,0,0);
run(c,1.5,none,'reposo: y(COM)=');
console.log('compresión ruedas', c.wheels.map(w=>w.comp.toFixed(1)).join(','));
run(c,3,{...none,throttle:1},'acelera 3s (no turbo)');
run(c,2,{...none,throttle:1,boost:true},'turbo 2s');
c.reset(0,0,0); run(c,2,{...none,throttle:1,steer:1},'giro dcha 2s'); console.log('  hacia', (-c.bx).toFixed(2),(-c.bz).toFixed(2));
c.reset(0,0,0); run(c,1.5,{...none,throttle:-1},'marcha atrás');
// salto + doble salto + flip
c.reset(0,0,0); run(c,0.5,none); let maxY=0;
run(c,1.0,(t)=>{ const j = t<0.3 || (t>0.5&&t<0.55); maxY=Math.max(maxY,c.py); return {...none,jump:j,pitch:t>0.5?1:0}; },'salto+flip');
console.log('  altura máx', maxY.toFixed(0));
// subir pared: hacia +x desde el centro a tope con turbo
c.reset(0,0,0); c.q=RL.quatFromYaw(-Math.PI/2); RL.quatAxes(c.q,c);
let maxH=0, nanOk=true;
run(c,8,(t)=>{maxH=Math.max(maxH,c.py);return {...none,throttle:1,boost:c.boost>0&&true};},'pared');
console.log('  altura máxima en pared', maxH.toFixed(0), 'pos x', c.px.toFixed(0), 'dentro?', RL.arenaContact(c.px,c.py,c.pz,{}).d.toFixed(1));
// coche contra pelota
const b = RL.newBall(); b.px=0;b.py=92;b.pz=-600;
c.reset(0,-1500,Math.PI); // yaw π → mira +Z
let hits=0;
for(let i=0;i<4*120;i++){ c.step(dt,{...none,throttle:1,boost:true}); RL.stepBall(b,dt); b.tnow={}; const h=RL.carBallCollide(b,c,!b.tprev[1],{x:c.px,y:c.py,z:c.pz}); if(h>0){b.tnow[1]=true;hits++;} b.tprev=b.tnow; }
console.log('pelota tras golpe: z',b.pz.toFixed(0),'vel',Math.hypot(b.vx,b.vy,b.vz).toFixed(0),'contactos',hits);
// pelota rebota en suelo y paredes
const b2=RL.newBall(); b2.py=1500;b2.vx=1500;b2.vz=2000; let minY=1e9,bounces=0,prevVy=0;
for(let i=0;i<10*120;i++){RL.stepBall(b2,dt); if(prevVy<0&&b2.vy>0)bounces++; prevVy=b2.vy; if(!isFinite(b2.px))throw 1; const d=RL.arenaContact(b2.px,b2.py,b2.pz,{}).d; minY=Math.min(minY,d);}
console.log('pelota 10s: rebotes suelo',bounces,'prof.min',minY.toFixed(1),'pos',b2.px.toFixed(0),b2.py.toFixed(0),b2.pz.toFixed(0));
// gol
const b3=RL.newBall(); b3.pz=4500;b3.py=300;b3.vz=2500; for(let i=0;i<240;i++)RL.stepBall(b3,dt); console.log('gol: z',b3.pz.toFixed(0),'(>5211 = dentro de portería)');
const b4=RL.newBall(); b4.pz=4500;b4.px=1500;b4.py=300;b4.vz=2500; for(let i=0;i<240;i++)RL.stepBall(b4,dt); console.log('fuera del poste: z',b4.pz.toFixed(0),'(<5120 = rebota)');
