// Dos clientes del juego (código real del navegador con DOM/THREE simulados) contra el servidor real, misma sala por código.
process.env.PORT = 4001;
const vm = require('vm'), fs = require('fs'), path = require('path');
const {server} = require('../server/server.js');
const root = path.join(__dirname, '..');
const sleep = ms => new Promise(r => setTimeout(r, ms));
function makeClient(name) {
  const el = () => ({classList: {add() {}, remove() {}, toggle() {}, contains() { return false; }}, style: {}, children: [], addEventListener() {}, appendChild() {}, append() {}, remove() {}, focus() {}, value: '', textContent: '', innerHTML: '', width: 512, height: 256, firstChild: {}, lastChild: {}, dataset: {},
    getContext() { return new Proxy({}, {get: (t, k) => k === 'createImageData' ? (w, h) => ({data: new Uint8ClampedArray(w * h * 4)}) : k === 'createRadialGradient' ? () => ({addColorStop() {}}) : () => ({})}); }});
  const els = {}, handlers = {}, logs = [];
  const any = () => { const f = function () { return any(); }; return new Proxy(f, {get: (t, k) => k === Symbol.toPrimitive ? () => 0 : k === 'then' ? undefined : (k in t ? t[k] : (t[k] = any())), set: (t, k, v) => (t[k] = v, true), construct: () => any(), apply: () => any()}); };
  class V3 { constructor(x = 0, y = 0, z = 0) { this.x = x; this.y = y; this.z = z; } set(x, y, z) { this.x = x; this.y = y; this.z = z; return this; } copy(v) { this.x = v.x; this.y = v.y; this.z = v.z; return this; } clone() { return new V3(this.x, this.y, this.z); } addScaledVector(v, s) { this.x += v.x * s; this.y += v.y * s; this.z += v.z * s; return this; } dot(v) { return this.x * v.x + this.y * v.y + this.z * v.z; } lengthSq() { return this.dot(this); } length() { return Math.sqrt(this.lengthSq()); } normalize() { const l = this.length() || 1; this.x /= l; this.y /= l; this.z /= l; return this; } lerp(v, k) { this.x += (v.x - this.x) * k; this.y += (v.y - this.y) * k; this.z += (v.z - this.z) * k; return this; } setScalar(s) { return this.set(s, s, s); } }
  const THREE = new Proxy({Vector3: V3, Color: class { set() { return this; } clone() { return this; } lerp() { return this; } multiplyScalar() { return this; } setRGB() { return this; } }, SRGBColorSpace: 's', Float32BufferAttribute: class {}, BufferAttribute: class {}}, {get: (t, k) => k in t ? t[k] : (t[k] = any())});
  const sb = {console: {log() {}, warn() {}, error: (...a) => logs.push(a.join(' '))}, Math, Date, JSON, Object, Array, Number, String, Promise, Uint8ClampedArray, Float32Array, setTimeout, setInterval, clearInterval, clearTimeout, performance, THREE, WebSocket,
    location: {protocol: 'http:', host: 'localhost:4001'}, localStorage: {getItem() { return null; }, setItem() {}}, navigator: {}, document: {getElementById: id => els[id] || (els[id] = el()), createElement: () => el(), querySelectorAll: () => [], querySelector: () => el(), addEventListener: (e, f) => { (handlers[e] = handlers[e] || []).push(f); }, body: el()},
    devicePixelRatio: 1, innerWidth: 1280, innerHeight: 720, requestAnimationFrame: () => 1, cancelAnimationFrame() {}};
  sb.window = sb; sb.self = sb; sb.addEventListener = () => {};
  const ctx = vm.createContext(sb);
  ['shared/rlcore.js', 'js/physics.js', 'js/input.js', 'js/camera.js', 'js/cars.js', 'js/carmodel.js', 'js/ball.js', 'js/stadium.js', 'js/ui.js', 'js/audio.js', 'js/network.js', 'js/game.js', 'js/main.js'].forEach(f => vm.runInContext(fs.readFileSync(path.join(root, f), 'utf8'), ctx, {filename: f}));
  (handlers.DOMContentLoaded || []).forEach(f => f());
  return {name, run: s => vm.runInContext(s, ctx), els, logs};
}
(async () => {
  await new Promise(r => server.listen(4001, r));
  const A = makeClient('Ana'), B = makeClient('Beto');
  A.run('gameSettings.name="Ana"'); B.run('gameSettings.name="Beto"');
  A.run('createRoom()'); await sleep(400);
  const code = A.run('Net.room'); console.log('✓ Ana crea sala vía createRoom() → código', code, '| texto mostrado:', A.els['room-code'].textContent);
  B.els['join-code'].value = code; B.run('joinRoom()'); await sleep(400);
  console.log('✓ Beto se une con joinRoom() | jugadores en lobby A:', A.run('Net.players.length'), 'B:', B.run('Net.players.length'), '| equipos:', A.run('Net.players.map(p=>p.team)'));
  A.run('enterOnlineGame()'); B.run('enterOnlineGame()');
  let t = 1000;
  const tick = async (secs) => { for (let i = 0; i < secs * 60; i++) { t += 1000 / 60; A.run('frame(' + t + ')'); B.run('frame(' + t + ')'); if (i % 3 === 0) await sleep(16); } };
  await tick(5);   // cuenta atrás + inicio
  console.log('✓ ambos en el campo | fase A:', A.run('world.phase'), '| fase B:', B.run('world.phase'), '| remotos A:', A.run('Object.keys(world.remote).length'), 'B:', B.run('Object.keys(world.remote).length'));
  A.run('inputState.keys["w"]=true; inputState.keys["shift"]=true');
  await tick(4);
  const aPos = A.run('[gameObjects.player.px,gameObjects.player.pz].map(Math.round)'), aSeenByB = B.run('(()=>{const r=Object.values(world.remote)[0];return [r.px,r.pz].map(Math.round)})()');
  console.log('✓ movimiento sincronizado | A real', aPos, '| A visto por B', aSeenByB);
  const bA = A.run('[gameObjects.ball.px,gameObjects.ball.py,gameObjects.ball.pz].map(Math.round)'), bB = B.run('[gameObjects.ball.px,gameObjects.ball.py,gameObjects.ball.pz].map(Math.round)');
  console.log('✓ pelota A', bA, '| pelota B', bB, '| marcador A', A.run('world.score'), 'B', B.run('world.score'));
  if (Math.hypot(aPos[0] - aSeenByB[0], aPos[1] - aSeenByB[1]) > 700) throw new Error('coche remoto no sincronizado');
  if (Math.hypot(bA[0] - bB[0], bA[2] - bB[2]) > 400) throw new Error('pelota no sincronizada');
  B.run('Net.leave()'); await sleep(300);
  console.log('✓ B se desconecta → A recibe aviso | jugadores en A:', A.run('Net.players.length'), '| remotos en A:', A.run('Object.keys(world.remote).length'));
  console.log('errores de consola:', A.logs.concat(B.logs).length ? A.logs.concat(B.logs) : 'ninguno');
  server.close(); console.log('ONLINE SMOKE OK'); process.exit(0);
})().catch(e => { console.error('FALLO', e); process.exit(1); });
