// Prueba de humo del cliente: carga todos los scripts del navegador con un DOM y un THREE simulados
// y ejecuta el juego (modo solo con bots) durante varios segundos para detectar errores de ejecución.
const vm = require('vm'), fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..');
const el = () => { const o = {classList: {add() {}, remove() {}, toggle() {}, contains() { return false; }}, style: {}, children: [], addEventListener() {}, appendChild(c) { this.children.push(c); }, append() {}, remove() {}, setAttribute() {}, focus() {}, value: '', textContent: '', innerHTML: '', width: 512, height: 256, offsetWidth: 800, offsetHeight: 600, firstChild: {}, lastChild: {}, dataset: {},
    getContext() { return new Proxy({}, {get: (t, k) => k === 'createImageData' ? (w, h) => ({data: new Uint8ClampedArray(w * h * 4)}) : k === 'createRadialGradient' || k === 'createLinearGradient' ? () => ({addColorStop() {}}) : () => ({})}); }};
  return o; };
const els = {};
const handlers = {};
function anyProxy() { const f = function () { return anyProxy(); }; return new Proxy(f, {get: (t, k) => k === Symbol.toPrimitive ? () => 0 : k === 'then' ? undefined : (k in t ? t[k] : (t[k] = anyProxy())), set: (t, k, v) => (t[k] = v, true), construct: () => anyProxy(), apply: () => anyProxy()}); }
class V3 { constructor(x = 0, y = 0, z = 0) { this.x = x; this.y = y; this.z = z; } set(x, y, z) { this.x = x; this.y = y; this.z = z; return this; } copy(v) { this.x = v.x; this.y = v.y; this.z = v.z; return this; } clone() { return new V3(this.x, this.y, this.z); }
  addScaledVector(v, s) { this.x += v.x * s; this.y += v.y * s; this.z += v.z * s; return this; } dot(v) { return this.x * v.x + this.y * v.y + this.z * v.z; } lengthSq() { return this.dot(this); } length() { return Math.sqrt(this.lengthSq()); }
  normalize() { const l = this.length() || 1; this.x /= l; this.y /= l; this.z /= l; return this; } lerp(v, k) { this.x += (v.x - this.x) * k; this.y += (v.y - this.y) * k; this.z += (v.z - this.z) * k; return this; } setScalar(s) { return this.set(s, s, s); } }
const THREE = new Proxy({Vector3: V3, Color: class { constructor(c) { this.r = 1; this.g = 1; this.b = 1; } set() { return this; } clone() { return new this.constructor(); } lerp() { return this; } multiplyScalar() { return this; } setRGB() { return this; } }, SRGBColorSpace: 'srgb', AdditiveBlending: 2, DoubleSide: 2, BackSide: 1, RepeatWrapping: 1000, ACESFilmicToneMapping: 4, Float32BufferAttribute: class {}, BufferAttribute: class {}}, {get: (t, k) => k in t ? t[k] : (t[k] = anyProxy())});
const sandbox = {console, Math, Date, JSON, Object, Array, Number, String, Promise, Uint8ClampedArray, Float32Array, setTimeout, clearInterval, setInterval, clearTimeout, performance, THREE,
  location: {protocol: 'http:', host: 'localhost:3000'}, localStorage: {getItem() { return null; }, setItem() {}}, navigator: {}, WebSocket: function () {},
  document: {getElementById: id => els[id] || (els[id] = el()), createElement: () => el(), querySelectorAll: () => [], querySelector: () => el(), addEventListener: (e, f) => { (handlers[e] = handlers[e] || []).push(f); }, body: el()},
  devicePixelRatio: 1, innerWidth: 1280, innerHeight: 720, requestAnimationFrame: () => 1, cancelAnimationFrame() {}, AudioContext: undefined};
sandbox.window = sandbox; sandbox.self = sandbox; sandbox.addEventListener = () => {};
const ctx = vm.createContext(sandbox);
['shared/rlcore.js', 'js/physics.js', 'js/input.js', 'js/camera.js', 'js/cars.js', 'js/carmodel.js', 'js/ball.js', 'js/stadium.js', 'js/ui.js', 'js/audio.js', 'js/network.js', 'js/game.js', 'js/main.js']
  .forEach(f => vm.runInContext(fs.readFileSync(path.join(root, f), 'utf8'), ctx, {filename: f}));
(handlers.DOMContentLoaded || []).forEach(f => f());
const run = s => vm.runInContext(s, ctx);
run('startGame()');
console.log('✓ startGame() sin errores | modo:', run('world.mode'), '| coches en partida:', run('Object.keys(world.players).length'));
run('inputState.keys["w"]=true');
let t = 1000, maxSpeed = 0, sawPlaying = false, goals = 0;
for (let i = 0; i < 60 * 22; i++) {
  t += 1000 / 60;
  if (i === 60 * 5) run('inputState.keys[" "]=true'); if (i === 60 * 5 + 6) run('inputState.keys[" "]=false');
  if (i === 60 * 6) run('inputState.keys["shift"]=true');
  run('frame(' + t + ')');
  maxSpeed = Math.max(maxSpeed, run('Math.hypot(gameObjects.player.vx,gameObjects.player.vy,gameObjects.player.vz)'));
  if (run('world.phase') === 'playing') sawPlaying = true;
}
const s = run('({p:[gameObjects.player.px,gameObjects.player.py,gameObjects.player.pz].map(Math.round), ball:[gameObjects.ball.px,gameObjects.ball.py,gameObjects.ball.pz].map(Math.round), phase:world.phase, score:world.score, boost:Math.round(gameObjects.player.boost), bots:gameObjects.bots.map(b=>[Math.round(b.body.px),Math.round(b.body.pz),Math.round(Math.hypot(b.body.vx,b.body.vz))])})');
console.log('✓ 22 s simulados sin errores. Coche en', s.p, '| pelota en', s.ball, '| fase', s.phase, '| marcador', s.score, '| turbo', s.boost);
console.log('  velocidad máxima del coche:', Math.round(maxSpeed), '| bots (x,z,vel):', JSON.stringify(s.bots));
if (!sawPlaying) throw new Error('la partida nunca pasó de la cuenta atrás');
if (maxSpeed < 1200) throw new Error('el coche no acelera');
run('returnToMenu()'); console.log('✓ returnToMenu()/cleanupGame() sin errores');
console.log('SMOKE OK'); process.exit(0);
