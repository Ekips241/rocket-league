// Prueba de integración: dos clientes WebSocket reales, misma sala por código.
process.env.PORT = 3999;
const { server } = require('../server/server.js');
const RL = require('../shared/rlcore.js');
const assert = require('assert');
const sleep = ms => new Promise(r => setTimeout(r, ms));
function client(name) {
  const c = { name, msgs: [], snaps: [], ws: new WebSocket('ws://localhost:3999/ws') };
  c.ws.onmessage = e => { const m = JSON.parse(e.data); c.msgs.push(m); if (m.t === 'snap') c.snaps.push(m); if (m.t === 'hello') c.id = m.id; };
  c.send = o => c.ws.send(JSON.stringify(o));
  c.open = new Promise(r => c.ws.onopen = r);
  c.find = t => c.msgs.find(m => m.t === t);
  return c;
}
(async () => {
  await new Promise(r => server.listen(3999, r));
  const A = client('Ana'), B = client('Beto'); await A.open; await B.open;
  A.send({ t: 'create', name: 'Ana', look: { c1: '#ff0000' } }); await sleep(150);
  const joinedA = A.find('joined'); assert(joinedA, 'A no recibió joined'); const code = joinedA.room;
  assert(/^[A-Z2-9]{6}$/.test(code), 'código inválido ' + code); console.log('✓ sala creada con código', code, '| equipo A =', joinedA.team);
  B.send({ t: 'join', code: code.toLowerCase(), name: 'Beto' }); await sleep(150);
  const joinedB = B.find('joined'); assert(joinedB, 'B no pudo unirse'); assert(joinedB.players.length === 2); console.log('✓ B se unió con el mismo código | equipo B =', joinedB.team, '(equilibrado)');
  assert.notStrictEqual(joinedA.team, joinedB.team);
  assert(A.msgs.some(m => m.t === 'players' && m.players.length === 2), 'A no fue avisado de B'); console.log('✓ A ve a 2 jugadores conectados');
  const bad = client('x'); await bad.open; bad.send({ t: 'join', code: 'ZZZZZZ' }); await sleep(100); assert(bad.find('error')); console.log('✓ código inexistente → error:', bad.find('error').msg); bad.ws.close();
  await sleep(3300);   // cuenta atrás
  // A (azul) se lanza contra la pelota hacia la portería +Z a 1500 uu/s
  const q = RL.quatFromYaw(Math.PI); let z = -700;
  for (let i = 0; i < 90; i++) {
    z += 1500 / 30; A.send({ t: 's', p: [0, 18.5, z], v: [0, 0, 1500], q, w: [0, 0, 0], b: 50, st: 0, f: 1 });
    B.send({ t: 's', p: [2000, 18.5, 3000], v: [0, 0, 0], q: [0, 0, 0, 1], w: [0, 0, 0], b: 33, st: 0, f: 2 }); await sleep(33);
  }
  const la = A.snaps[A.snaps.length - 1], lb = B.snaps[B.snaps.length - 1];
  assert(la.cars[A.id] && la.cars[B.id], 'snapshot sin los dos coches');
  console.log('✓ snapshots a ~30Hz:', A.snaps.length, 'en ~3s | coches en snap:', Object.keys(la.cars).length);
  assert(Math.abs(lb.cars[A.id][2] - la.cars[A.id][2]) < 200, 'posición de A no sincronizada en B'); console.log('✓ coche de A visible en B (z =', lb.cars[A.id][2].toFixed(0) + ')');
  const goal = A.msgs.find(m => m.t === 'ev' && m.e.type === 'goal') || B.msgs.find(m => m.t === 'ev' && m.e.type === 'goal');
  console.log('  pelota z =', la.ball[2], 'vz =', la.ball[5], '| marcador', JSON.stringify(la.score), '| fase', la.ph);
  assert(la.ball[2] > 100 || goal, 'la pelota no se movió tras el golpe'); console.log('✓ pelota golpeada y sincronizada en ambos clientes', goal ? '| GOL: ' + JSON.stringify(goal.e.score) : '');
  assert.deepStrictEqual(la.ball.slice(0, 3).map(Math.round).length, 3);
  A.ws.close(); await sleep(200);
  const left = B.msgs.find(m => m.t === 'left'); assert(left && left.name === 'Ana'); console.log('✓ B recibe aviso de desconexión de', left.name, '| jugadores restantes:', left.players.length);
  B.ws.close(); await sleep(100); server.close(); console.log('TODO OK'); process.exit(0);
})().catch(e => { console.error('FALLO', e); process.exit(1); });
